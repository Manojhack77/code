package com.manhour.service;

import static com.manhour.dto.Dtos.*;
import static com.manhour.service.Money.r2;

import com.manhour.model.AppUser;
import com.manhour.model.BaseRateChange;
import com.manhour.model.Booking;
import com.manhour.model.MonthlyHours;
import com.manhour.model.Project;
import com.manhour.model.ProjectMapping;
import com.manhour.model.Role;
import com.manhour.repo.BaseRateRepository;
import com.manhour.repo.BookingRepository;
import com.manhour.repo.MappingRepository;
import com.manhour.repo.ProjectMemberRepository;
import com.manhour.repo.MonthlyHoursRepository;
import com.manhour.repo.ProjectRepository;
import com.manhour.repo.UserRepository;
import com.manhour.web.ApiException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.YearMonth;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.stream.Collectors;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * The Member mapping page. An employee's hours for a month are 100%; this service splits them across projects.
 * Percentage and hours always stay in step: hours = typed total x %, and % = hours / typed total x 100.
 * No project expiry lock: the only lock is a finalized month (PeriodService).
 */
@Service
public class AllocationService {
    private static final BigDecimal HUNDRED = BigDecimal.valueOf(100);
    private static final BigDecimal MAX_HOURS = BigDecimal.valueOf(744);
    private static final BigDecimal TOLERANCE = new BigDecimal("0.02");
    private final UserRepository users;
    private final ProjectRepository projects;
    private final MappingRepository mappings;
    private final ProjectMemberRepository members;
    private final BookingRepository bookings;
    private final MonthlyHoursRepository monthly;
    private final BaseRateRepository rates;
    private final BudgetService budget;
    private final PeriodService periods;

    public AllocationService(UserRepository users, ProjectRepository projects, MappingRepository mappings,
                             ProjectMemberRepository members, BookingRepository bookings, MonthlyHoursRepository monthly, BaseRateRepository rates,
                             BudgetService budget, PeriodService periods) {
        this.users = users;
        this.projects = projects;
        this.mappings = mappings;
        this.members = members;
        this.bookings = bookings;
        this.monthly = monthly;
        this.rates = rates;
        this.budget = budget;
        this.periods = periods;
    }

    private static String plain(BigDecimal v) {
        return r2(v).stripTrailingZeros().toPlainString();
    }

    private AppUser staffUser(String memberId) {
        return users.findById(memberId == null ? "" : memberId.trim()).filter(u -> u.getRole() == Role.STAFF)
                .orElseThrow(() -> ApiException.notFound("Staff member not found."));
    }

    private BigDecimal rateFor(int month, int year) {
        String ym = PeriodService.key(month, year);
        return rates.findFirstByEffectiveFromLessThanEqualOrderByEffectiveFromDesc(ym).map(BaseRateChange::getRate)
                .orElseThrow(() -> ApiException.bad("No base rate is set for " + ym + "."));
    }

    // ---------------- employee list ----------------
    /**
     * One row per employee for the chosen month: typed hours and how much of them is allocated. An employee
     * with no hours that month shows the standing (default) allocation instead, marked fromDefault.
     */
    @Transactional(readOnly = true)
    public List<AllocationSummary> list(Integer month, Integer year) {
        YearMonth now = YearMonth.now();
        int m = month == null ? now.getMonthValue() : month;
        int y = year == null ? now.getYear() : year;
        if (m < 1 || m > 12 || y < 2000 || y > 2100) throw ApiException.bad("Choose a valid month and year.");
        boolean fin = periods.isFinal(m, y);
        Map<String, BigDecimal> standing = new HashMap<>();
        for (ProjectMapping pm : mappings.findAll()) standing.merge(pm.getMemberId(), pm.getAllocationPercentage(), BigDecimal::add);
        Map<String, BigDecimal> typed = new HashMap<>();
        for (MonthlyHours mh : monthly.findByMonthAndYear(m, y)) typed.put(mh.getMemberId(), r2(mh.getTotalHours()));
        Map<String, BigDecimal> used = new HashMap<>();
        for (Booking b : bookings.search(m, y)) used.merge(b.getMemberId(), b.getAllocationPercentage(), BigDecimal::add);
        return users.findByRoleOrderByMemberId(Role.STAFF).stream().map(u -> {
            String id = u.getMemberId();
            BigDecimal t = typed.get(id);
            boolean has = t != null || used.containsKey(id);
            BigDecimal def = r2(standing.getOrDefault(id, BigDecimal.ZERO));
            BigDecimal total = has ? r2(used.getOrDefault(id, BigDecimal.ZERO)) : def;
            BigDecimal rem = r2(HUNDRED.subtract(total));
            String status = !has ? "No hours" : total.signum() == 0 ? "Not assigned"
                    : rem.compareTo(TOLERANCE) <= 0 ? "Fully allocated" : "Partly allocated";
            return new AllocationSummary(id, u.getName(), t, total, rem, status, !has, fin);
        }).toList();
    }

    // ---------------- view / edit data ----------------
    /** One employee for one month. With no month given, the latest month with submitted hours is used. */
    @Transactional(readOnly = true)
    public AllocationDetail detail(String memberId, Integer month, Integer year) {
        AppUser u = staffUser(memberId);
        TreeMap<String, MonthOption> opts = new TreeMap<>(Comparator.reverseOrder());
        for (MonthlyHours mh : monthly.findByMemberId(u.getMemberId())) {
            opts.put(PeriodService.key(mh.getMonth(), mh.getYear()), new MonthOption(mh.getMonth(), mh.getYear(),
                    r2(mh.getTotalHours()), periods.isFinal(mh.getMonth(), mh.getYear())));
        }
        int m;
        int y;
        if (month != null && year != null) {
            m = month;
            y = year;
        } else if (!opts.isEmpty()) {
            MonthOption first = opts.firstEntry().getValue();
            m = first.month();
            y = first.year();
        } else {
            YearMonth now = YearMonth.now();
            m = now.getMonthValue();
            y = now.getYear();
        }
        if (m < 1 || m > 12) throw ApiException.bad("Choose a valid month.");
        MonthOption cur = opts.get(PeriodService.key(m, y));
        BigDecimal typed = cur == null ? null : cur.typedHours();
        Map<String, Project> pById = projects.findAll().stream().collect(Collectors.toMap(Project::getWbsCode, p -> p));
        List<Booking> rows = new ArrayList<>(bookings.findByMemberIdAndMonthAndYear(u.getMemberId(), m, y));
        rows.sort(Comparator.comparing(Booking::getWbsCode));
        List<AllocationRow> out = new ArrayList<>();
        BigDecimal tp = BigDecimal.ZERO;
        BigDecimal th = BigDecimal.ZERO;
        BigDecimal tc = BigDecimal.ZERO;
        for (Booking b : rows) {
            Project p = pById.get(b.getWbsCode());
            out.add(new AllocationRow(b.getWbsCode(), p == null ? "" : p.getProjectName(), p != null && p.isExpired(),
                    r2(b.getAllocationPercentage()), r2(b.getHoursBooked()), r2(b.getRateApplied()), r2(b.getCalculatedCost())));
            tp = tp.add(b.getAllocationPercentage());
            th = th.add(b.getHoursBooked());
            tc = tc.add(b.getCalculatedCost());
        }
        BigDecimal remHours = typed == null ? r2(BigDecimal.ZERO) : r2(typed.subtract(th));
        BigDecimal rate = rates.findFirstByEffectiveFromLessThanEqualOrderByEffectiveFromDesc(PeriodService.key(m, y))
                .map(BaseRateChange::getRate).orElse(null);
        List<StandingRow> standing = new ArrayList<>();
        for (ProjectMapping pm : mappings.findByMemberId(u.getMemberId())) {
            Project p = pById.get(pm.getWbsCode());
            standing.add(new StandingRow(pm.getWbsCode(), p == null ? "" : p.getProjectName(), p != null && p.isExpired(),
                    r2(pm.getAllocationPercentage())));
        }
        standing.sort(Comparator.comparing(StandingRow::wbsCode));
        return new AllocationDetail(u.getMemberId(), u.getName(), m, y, typed, periods.isFinal(m, y), rate, out,
                r2(tp), r2(th), r2(tc), r2(HUNDRED.subtract(tp)), remHours, new ArrayList<>(opts.values()), standing);
    }

    // ---------------- edit (hours or %) ----------------
    /**
     * Saves one month's split. Each row carries its hours; the % is worked out from them (the screen fills in
     * the hours when a % is typed, so both ways end up here). Rows missing from the request, or with 0 hours,
     * are removed. Budgets move by the change in cost. Optionally the same split becomes the default for months
     * that are submitted from now on.
     */
    @Transactional
    public MessageResponse save(String memberId, AllocationSaveRequest r) {
        AppUser u = staffUser(memberId);
        if (r.month() == null || r.year() == null || r.month() < 1 || r.month() > 12 || r.year() < 2000 || r.year() > 2100)
            throw ApiException.bad("Choose a valid month and year.");
        int month = r.month();
        int year = r.year();
        periods.requireOpen(month, year);
        MonthlyHours mh = monthly.findByMemberIdAndMonthAndYear(u.getMemberId(), month, year)
                .orElseThrow(() -> ApiException.bad("No hours were submitted for this month."));
        BigDecimal typed = r2(mh.getTotalHours());
        if (r.rows() == null) throw ApiException.bad("Nothing to save.");

        Map<String, BigDecimal> want = new LinkedHashMap<>();
        for (AllocationInput in : r.rows()) {
            String wbs = in.wbsCode() == null ? "" : in.wbsCode().trim();
            if (wbs.isEmpty()) throw ApiException.bad("Choose a project for every row.");
            if (want.containsKey(wbs)) throw ApiException.bad("Project " + wbs + " is listed twice.");
            if (in.hours() == null || in.hours().signum() < 0) throw ApiException.bad("Hours cannot be negative.");
            if (!projects.existsById(wbs)) throw ApiException.notFound("Project " + wbs + " does not exist.");
            // A project can only be added to a month if the employee is a member of it (rows already there stay).
            if (in.hours().signum() > 0 && !members.existsByWbsCodeAndMemberId(wbs, u.getMemberId())
                    && !bookings.existsByMemberIdAndWbsCodeAndMonthAndYear(u.getMemberId(), wbs, month, year))
                throw ApiException.bad(u.getName() + " is not a member of " + wbs + ". Add them under Projects first.");
            want.put(wbs, r2(in.hours()));
        }
        BigDecimal sum = want.values().stream().reduce(BigDecimal.ZERO, BigDecimal::add);
        if (sum.compareTo(typed) > 0)
            throw ApiException.bad("The allocated hours (" + plain(sum) + ") cannot be more than the hours booked ("
                    + plain(typed) + "), which is 100%.");

        // % from hours, rounded to 2 decimals; the rounding can leave the total a hair over 100, so trim the largest.
        Map<String, BigDecimal> pct = new LinkedHashMap<>();
        for (var e : want.entrySet()) {
            if (e.getValue().signum() > 0)
                pct.put(e.getKey(), r2(e.getValue().multiply(HUNDRED).divide(typed, 4, RoundingMode.HALF_UP)));
        }
        fit(pct);

        Map<String, Booking> existing = new LinkedHashMap<>();
        for (Booking b : bookings.findByMemberIdAndMonthAndYear(u.getMemberId(), month, year)) existing.put(b.getWbsCode(), b);
        Map<String, BigDecimal> deltas = new LinkedHashMap<>();
        List<Booking> toSave = new ArrayList<>();
        List<Booking> toDelete = new ArrayList<>();
        BigDecimal newRate = null;
        for (var e : want.entrySet()) {
            Booking b = existing.remove(e.getKey());
            BigDecimal h = e.getValue();
            if (h.signum() == 0) { // 0 hours means "remove this project from the month"
                if (b != null) {
                    toDelete.add(b);
                    deltas.merge(e.getKey(), b.getCalculatedCost().negate(), BigDecimal::add);
                }
                continue;
            }
            BigDecimal old = BigDecimal.ZERO;
            if (b == null) {
                if (newRate == null) newRate = rateFor(month, year);
                b = new Booking();
                b.setMemberId(u.getMemberId());
                b.setWbsCode(e.getKey());
                b.setMonth(month);
                b.setYear(year);
                b.setRateApplied(newRate);
            } else {
                old = b.getCalculatedCost();
            }
            BigDecimal cost = r2(h.multiply(b.getRateApplied()));
            deltas.merge(e.getKey(), cost.subtract(old), BigDecimal::add);
            b.setAllocationPercentage(pct.get(e.getKey()));
            b.setHoursBooked(h);
            b.setCalculatedCost(cost);
            toSave.add(b);
        }
        for (Booking b : existing.values()) { // rows the request did not mention are removed too
            toDelete.add(b);
            deltas.merge(b.getWbsCode(), b.getCalculatedCost().negate(), BigDecimal::add);
        }
        budget.apply(deltas, true); // admin sees amounts if a budget is short
        bookings.deleteAll(toDelete);
        bookings.saveAll(toSave);

        if (Boolean.TRUE.equals(r.applyToDefault())) syncDefault(u.getMemberId(), pct);
        return new MessageResponse("Allocation saved.");
    }

    /** Makes the saved split the employee's default for months submitted from now on. */
    private void syncDefault(String memberId, Map<String, BigDecimal> pct) {
        Map<String, ProjectMapping> mine = new LinkedHashMap<>();
        for (ProjectMapping m : mappings.findByMemberId(memberId)) mine.put(m.getWbsCode(), m);
        for (var e : pct.entrySet()) {
            ProjectMapping m = mine.remove(e.getKey());
            if (m == null) {
                m = new ProjectMapping();
                m.setMemberId(memberId);
                m.setWbsCode(e.getKey());
            }
            m.setAllocationPercentage(e.getValue());
            mappings.save(m);
        }
        mappings.deleteAll(mine.values());
    }

    private static void fit(Map<String, BigDecimal> pct) {
        BigDecimal excess = pct.values().stream().reduce(BigDecimal.ZERO, BigDecimal::add).subtract(HUNDRED);
        if (excess.signum() <= 0) return;
        String biggest = null;
        for (var e : pct.entrySet()) if (biggest == null || e.getValue().compareTo(pct.get(biggest)) > 0) biggest = e.getKey();
        pct.put(biggest, pct.get(biggest).subtract(excess));
    }

    // ---------------- standing allocation (no hours yet) ----------------
    /**
     * Saves the employee's standing (default) allocation as percentages. Used by Edit/Assign when the month has
     * no hours: there is nothing to split yet, so only the % is set, and it is applied when hours are added.
     * Rows with 0% are removed; the total cannot exceed 100; a project that is new to the employee must be one
     * they are a member of.
     */
    @Transactional
    public MessageResponse saveDefault(String memberId, DefaultSaveRequest r) {
        AppUser u = staffUser(memberId);
        if (r == null || r.rows() == null) throw ApiException.bad("Nothing to save.");
        Map<String, BigDecimal> have = new HashMap<>();
        for (ProjectMapping m : mappings.findByMemberId(u.getMemberId())) have.put(m.getWbsCode(), m.getAllocationPercentage());
        Map<String, BigDecimal> want = new LinkedHashMap<>();
        BigDecimal sum = BigDecimal.ZERO;
        for (DefaultInput in : r.rows()) {
            String wbs = in.wbsCode() == null ? "" : in.wbsCode().trim();
            if (wbs.isEmpty()) throw ApiException.bad("Choose a project for every row.");
            if (want.containsKey(wbs)) throw ApiException.bad("Project " + wbs + " is listed twice.");
            if (in.percentage() == null || in.percentage().signum() < 0) throw ApiException.bad("Percentage cannot be negative.");
            if (!projects.existsById(wbs)) throw ApiException.notFound("Project " + wbs + " does not exist.");
            BigDecimal pct = r2(in.percentage());
            if (pct.compareTo(HUNDRED) > 0) throw ApiException.bad("Allocation cannot be more than 100%.");
            if (pct.signum() == 0) continue; // 0% means "remove this project"
            if (!have.containsKey(wbs) && !members.existsByWbsCodeAndMemberId(wbs, u.getMemberId()))
                throw ApiException.bad(u.getName() + " is not a member of " + wbs + ". Add them under Projects first.");
            want.put(wbs, pct);
            sum = sum.add(pct);
        }
        if (sum.compareTo(HUNDRED) > 0)
            throw ApiException.bad("The total allocation (" + plain(sum) + "%) cannot be more than 100%.");
        syncDefault(u.getMemberId(), want);
        return new MessageResponse("Allocation saved. It will be used when hours are added.");
    }

    // ---------------- total hours (add / edit) ----------------
    /**
     * Sets an employee's total hours for a month. Used by the admin (Member mapping table, may also ADD hours)
     * and by the staff member editing their own month (byAdmin = false, the month must already exist).
     * Each project row becomes total x its %, cost follows at the row's saved rate, project budgets move by the
     * difference. The employee sees the new value on their own page because it is the same monthly record.
     */
    @Transactional
    public MessageResponse setMonthHours(String memberId, int month, int year, BigDecimal hours, boolean byAdmin) {
        if (month < 1 || month > 12 || year < 2000 || year > 2100) throw ApiException.bad("Choose a valid month and year.");
        if (hours == null || hours.signum() < 0) throw ApiException.bad("Hours cannot be negative.");
        if (hours.compareTo(MAX_HOURS) > 0) throw ApiException.bad("Hours cannot exceed 744 in a month.");
        BigDecimal total = r2(hours);
        periods.requireOpen(month, year);
        AppUser u = byAdmin ? staffUser(memberId)
                : users.findById(memberId).orElseThrow(() -> ApiException.notFound("Account not found."));
        MonthlyHours mh = monthly.findByMemberIdAndMonthAndYear(u.getMemberId(), month, year).orElse(null);
        List<Booking> rows = new ArrayList<>(bookings.findByMemberIdAndMonthAndYear(u.getMemberId(), month, year));
        if (mh == null && rows.isEmpty()) {
            if (!byAdmin) throw ApiException.notFound("Booking not found.");
            if (total.signum() == 0) throw ApiException.bad("Enter hours greater than zero.");
            return addMonth(u, month, year, total);
        }
        if (mh == null) { // an older month that only has booking rows
            mh = new MonthlyHours();
            mh.setMemberId(u.getMemberId());
            mh.setMonth(month);
            mh.setYear(year);
        }
        rows.sort(Comparator.comparing(Booking::getWbsCode));
        Map<String, BigDecimal> mapPct = new LinkedHashMap<>();
        for (ProjectMapping pm : mappings.findByMemberId(u.getMemberId())) mapPct.put(pm.getWbsCode(), pm.getAllocationPercentage());
        Map<String, BigDecimal> deltas = new LinkedHashMap<>();
        List<BigDecimal> newHours = new ArrayList<>();
        List<BigDecimal> newCosts = new ArrayList<>();
        for (Booking b : rows) {
            BigDecimal pct = b.getAllocationPercentage();
            if (pct == null || pct.signum() == 0) pct = mapPct.getOrDefault(b.getWbsCode(), BigDecimal.ZERO);
            BigDecimal h = pct.signum() == 0 ? b.getHoursBooked()
                    : r2(total.multiply(pct).divide(HUNDRED, 4, RoundingMode.HALF_UP));
            BigDecimal cost = r2(h.multiply(b.getRateApplied()));
            newHours.add(h);
            newCosts.add(cost);
            deltas.merge(b.getWbsCode(), cost.subtract(b.getCalculatedCost()), BigDecimal::add);
        }
        budget.apply(deltas, byAdmin); // the admin sees amounts, staff see a plain message
        for (int i = 0; i < rows.size(); i++) {
            Booking b = rows.get(i);
            if (b.getAllocationPercentage() == null || b.getAllocationPercentage().signum() == 0)
                b.setAllocationPercentage(mapPct.getOrDefault(b.getWbsCode(), BigDecimal.ZERO));
            b.setHoursBooked(newHours.get(i));
            b.setCalculatedCost(newCosts.get(i));
        }
        mh.setTotalHours(total);
        monthly.save(mh);
        bookings.saveAll(rows);
        return new MessageResponse("Hours updated.");
    }

    /** First hours of a month entered by the admin: split by the employee's default allocation at that month's rate. */
    private MessageResponse addMonth(AppUser u, int month, int year, BigDecimal total) {
        List<ProjectMapping> maps = new ArrayList<>(mappings.findByMemberId(u.getMemberId()));
        maps.sort(Comparator.comparing(ProjectMapping::getWbsCode));
        List<Booking> rows = new ArrayList<>();
        Map<String, BigDecimal> deltas = new LinkedHashMap<>();
        if (!maps.isEmpty()) {
            BigDecimal rate = rateFor(month, year);
            for (ProjectMapping pm : maps) {
                if (!projects.existsById(pm.getWbsCode())) continue;
                BigDecimal h = r2(total.multiply(pm.getAllocationPercentage()).divide(HUNDRED, 4, RoundingMode.HALF_UP));
                BigDecimal cost = r2(h.multiply(rate));
                Booking b = new Booking();
                b.setMemberId(u.getMemberId());
                b.setWbsCode(pm.getWbsCode());
                b.setMonth(month);
                b.setYear(year);
                b.setAllocationPercentage(pm.getAllocationPercentage());
                b.setHoursBooked(h);
                b.setRateApplied(rate);
                b.setCalculatedCost(cost);
                rows.add(b);
                deltas.merge(pm.getWbsCode(), cost, BigDecimal::add);
            }
        }
        budget.apply(deltas, true);
        MonthlyHours mh = new MonthlyHours();
        mh.setMemberId(u.getMemberId());
        mh.setMonth(month);
        mh.setYear(year);
        mh.setTotalHours(total);
        monthly.save(mh);
        bookings.saveAll(rows);
        return new MessageResponse(rows.isEmpty() ? "Hours added. Nothing is assigned to a project yet." : "Hours added.");
    }
}
