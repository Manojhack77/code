package com.manhour.service;

import static com.manhour.dto.Dtos.*;
import static com.manhour.service.Money.r2;

import com.manhour.model.AppUser;
import com.manhour.model.Booking;
import com.manhour.model.MonthlyHours;
import com.manhour.model.Project;
import com.manhour.model.ProjectMapping;
import com.manhour.repo.BaseRateRepository;
import com.manhour.repo.BookingRepository;
import com.manhour.repo.MappingRepository;
import com.manhour.repo.MonthlyHoursRepository;
import com.manhour.repo.ProjectRepository;
import com.manhour.repo.UserRepository;
import com.manhour.security.AuthUser;
import com.manhour.web.ApiException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class StaffService {
    private static final BigDecimal MAX_HOURS = BigDecimal.valueOf(744);
    private static final BigDecimal HUNDRED = BigDecimal.valueOf(100);

    private final UserRepository users;
    private final ProjectRepository projects;
    private final MappingRepository mappings;
    private final BookingRepository bookings;
    private final BudgetService budget;
    private final BaseRateRepository rates;
    private final MonthlyHoursRepository monthly;
    private final PeriodService periods;
    private final AllocationService allocations;

    public StaffService(UserRepository users, ProjectRepository projects, MappingRepository mappings,
                        BookingRepository bookings, BudgetService budget, BaseRateRepository rates,
                        MonthlyHoursRepository monthly, PeriodService periods,
                        AllocationService allocations) {
        this.users = users;
        this.projects = projects;
        this.mappings = mappings;
        this.bookings = bookings;
        this.budget = budget;
        this.rates = rates;
        this.monthly = monthly;
        this.periods = periods;
        this.allocations = allocations;
    }

    /** Staff may only touch their own data. */
    private static void requireSelf(AuthUser me, String memberId) {
        if (memberId == null || !me.memberId().equalsIgnoreCase(memberId.trim()))
            throw ApiException.forbidden("You can only access your own bookings.");
    }

    /** Only projects the staff member is mapped to. No budget, cost or rate fields (FR-1.1). */
    @Transactional(readOnly = true)
    public List<StaffProjectView> projects(AuthUser me, String memberId) {
        requireSelf(me, memberId);
        List<StaffProjectView> out = new ArrayList<>();
        for (ProjectMapping m : mappings.findByMemberId(me.memberId())) {
            projects.findById(m.getWbsCode()).ifPresent(p -> out.add(new StaffProjectView(
                    p.getWbsCode(), p.getProjectName(), p.getExpiryDate(),
                    p.isExpired() ? "Expired" : "Active", m.getAllocationPercentage())));
        }
        return out;
    }

    /** One row per month, newest first. Shows the hours the staff member typed, including any unassigned part. */
    @Transactional(readOnly = true)
    public List<HistoryRow> history(AuthUser me, String memberId) {
        requireSelf(me, memberId);
        Map<String, HistoryRow> groups = new LinkedHashMap<>();
        // Older months that only have booking rows: show the sum of their rows.
        for (Booking b : bookings.findByMemberId(me.memberId())) {
            String id = me.memberId() + "_" + b.getYear() + "_" + b.getMonth();
            HistoryRow old = groups.get(id);
            BigDecimal hours = old == null ? b.getHoursBooked() : old.hours().add(b.getHoursBooked());
            groups.put(id, new HistoryRow(id, b.getMonth(), b.getYear(), r2(hours)));
        }
        // The typed total always wins: it includes the part that is not mapped to a project yet.
        for (MonthlyHours mh : monthly.findByMemberId(me.memberId())) {
            String id = me.memberId() + "_" + mh.getYear() + "_" + mh.getMonth();
            groups.put(id, new HistoryRow(id, mh.getMonth(), mh.getYear(), r2(mh.getTotalHours())));
        }
        List<HistoryRow> rows = new ArrayList<>(groups.values());
        rows.sort(Comparator.<HistoryRow>comparingInt(h -> h.year()).thenComparingInt(h -> h.month()).reversed());
        return rows;
    }

    /**
     * Saves the typed hours for the month (always, even with no project mapping). Then, for each mapped project,
     * creates a Booking row: hours_wbs = hours x allocation%, cost = hours_wbs x the base rate in force for the
     * booked month (saved on the row as rate_applied). The part that is not mapped (100% minus the mapped %)
     * is not costed now; it is allocated when an administrator maps it.
     */
    @Transactional
    public MessageResponse book(AuthUser me, BookRequest r) {
        requireSelf(me, r.memberId());
        if (r.month() == null || r.month() < 1 || r.month() > 12 || r.year() == null || r.year() < 2000 || r.year() > 2100)
            throw ApiException.bad("Choose a valid month and year.");
        if (r.hours() == null || r.hours().signum() <= 0) throw ApiException.bad("Enter hours greater than zero.");
        if (r.hours().compareTo(MAX_HOURS) > 0)
            throw ApiException.bad("Hours cannot exceed the number of hours in a month (744).");

        periods.requireOpen(r.month(), r.year()); // a finalized month is closed to new hours
        AppUser u = users.findById(me.memberId()).orElseThrow(() -> ApiException.notFound("Account not found."));
        if (monthly.existsByMemberIdAndMonthAndYear(u.getMemberId(), r.month(), r.year())
                || bookings.existsByMemberIdAndMonthAndYear(u.getMemberId(), r.month(), r.year()))
            throw ApiException.bad("Hours for this month are already submitted. Use View to edit them.");
        List<ProjectMapping> maps = mappings.findByMemberId(u.getMemberId());
        BigDecimal total = r2(r.hours());
        List<Booking> rows = new ArrayList<>();
        Map<String, BigDecimal> deltas = new LinkedHashMap<>();
        BigDecimal mappedPct = BigDecimal.ZERO;
        if (!maps.isEmpty()) {
            // One base rate for everyone: the latest change that starts on or before the booked month.
            String ym = String.format("%04d-%02d", r.year(), r.month());
            BigDecimal rate = rates.findFirstByEffectiveFromLessThanEqualOrderByEffectiveFromDesc(ym)
                    .orElseThrow(() -> ApiException.bad("Your account is not ready for booking yet. Ask your administrator."))
                    .getRate();
            for (ProjectMapping m : maps) {
                Project pr = projects.findById(m.getWbsCode()).orElse(null);
                if (pr == null) continue; // an expired project still takes its share: only a finalized period locks costs
                BigDecimal h = r2(total.multiply(m.getAllocationPercentage()).divide(HUNDRED, 4, RoundingMode.HALF_UP));
                BigDecimal cost = r2(h.multiply(rate));
                Booking b = new Booking();
                b.setMemberId(u.getMemberId());
                b.setWbsCode(m.getWbsCode());
                b.setMonth(r.month());
                b.setYear(r.year());
                b.setAllocationPercentage(m.getAllocationPercentage());
                b.setHoursBooked(h);
                b.setRateApplied(rate);
                b.setCalculatedCost(cost);
                rows.add(b);
                deltas.merge(m.getWbsCode(), cost, BigDecimal::add);
                mappedPct = mappedPct.add(m.getAllocationPercentage());
            }
        }
        budget.apply(deltas, false); // staff-facing errors carry no amounts; nothing to check when no mapping
        MonthlyHours mh = new MonthlyHours();
        mh.setMemberId(u.getMemberId());
        mh.setMonth(r.month());
        mh.setYear(r.year());
        mh.setTotalHours(total);
        monthly.save(mh);
        bookings.saveAll(rows);
        if (mappedPct.compareTo(HUNDRED) >= 0) return new MessageResponse("Hours submitted successfully!");
        if (mappedPct.signum() == 0)
            return new MessageResponse("Hours submitted. You are not assigned to a project yet, so your hours will be "
                    + "counted when your administrator assigns you.");
        return new MessageResponse("Hours submitted. " + HUNDRED.subtract(mappedPct).stripTrailingZeros().toPlainString()
                + "% of your hours are not assigned to a project yet and will be counted when your administrator assigns them.");
    }

    /**
     * Staff edit their month: id = "<memberId>_<year>_<month>". The new total is split again by each row's saved %
     * (same logic the admin uses). A finalized month cannot be changed. Administrators change hours on the
     * Member mapping page.
     */
    @Transactional
    public MessageResponse updateHours(AuthUser me, String id, BigDecimal hours) {
        String[] parts = id.split("_");
        if (parts.length < 3) throw ApiException.notFound("Booking not found.");
        int month, year;
        try {
            month = Integer.parseInt(parts[parts.length - 1]);
            year = Integer.parseInt(parts[parts.length - 2]);
        } catch (NumberFormatException e) {
            throw ApiException.notFound("Booking not found.");
        }
        if (month < 1 || month > 12) throw ApiException.notFound("Booking not found.");
        String memberId = id.substring(0, id.length() - (parts[parts.length - 1].length() + parts[parts.length - 2].length() + 2));
        requireSelf(me, memberId);
        return allocations.setMonthHours(me.memberId(), month, year, hours, false);
    }
}
