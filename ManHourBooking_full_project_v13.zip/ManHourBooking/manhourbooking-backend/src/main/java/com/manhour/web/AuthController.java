package com.manhour.web;

import static com.manhour.dto.Dtos.*;

import com.manhour.service.AuthService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
public class AuthController {
    private final AuthService auth;

    public AuthController(AuthService auth) {
        this.auth = auth;
    }

    @PostMapping("/login")
    public AuthResponse login(@RequestBody LoginRequest r) { return auth.login(r); }

    @PostMapping("/signup")
    public MessageResponse signup(@RequestBody SignupRequest r) { return auth.signup(r); }

    @PostMapping("/forgot/question")
    public ForgotQuestionResponse question(@RequestBody ForgotQuestionRequest r) { return auth.forgotQuestion(r); }

    @PostMapping("/forgot/reset")
    public MessageResponse reset(@RequestBody ForgotResetRequest r) { return auth.forgotReset(r); }
}
