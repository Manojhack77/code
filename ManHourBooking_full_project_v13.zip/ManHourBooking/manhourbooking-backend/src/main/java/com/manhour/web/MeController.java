package com.manhour.web;

import static com.manhour.dto.Dtos.*;

import com.manhour.security.AuthUser;
import com.manhour.service.AuthService;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

/** The logged-in user's own profile (staff and admin). The ID always comes from the token, never from the URL. */
@RestController
@RequestMapping("/api/me")
public class MeController {
    private final AuthService auth;

    public MeController(AuthService auth) {
        this.auth = auth;
    }

    @GetMapping
    public ProfileView profile(@AuthenticationPrincipal AuthUser me) {
        return auth.profile(me.memberId());
    }

    @PutMapping
    public ProfileView update(@AuthenticationPrincipal AuthUser me, @RequestBody ProfileUpdateRequest r) {
        return auth.updateProfile(me.memberId(), r);
    }
}
