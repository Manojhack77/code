package com.manhour.dto;

import java.math.BigDecimal;
import java.time.LocalDate;

/** Request/response shapes, matching API_CONTRACT.md field for field. */
public final class Dtos {
    private Dtos() {}

    // ---- auth ----
    public record LoginRequest(String userId, String password) {}
    public record SignupRequest(String memberId, String name, String password, String securityQuestion, String securityAnswer) {}
    public record ForgotQuestionRequest(String userId) {}
    public record ForgotQuestionResponse(String question) {}
    public record ForgotResetRequest(String userId, String answer, String newPassword) {}
    public record UserInfo(String memberId, String name, String role) {}
    public record AuthResponse(String token, UserInfo user) {}
    public record MessageResponse(String message) {}
    public record ProfileView(String memberId, String name, String role, String securityQuestion) {}
    /** currentPassword is needed only when newPassword or securityAnswer is sent. */
    public record ProfileUpdateRequest(String name, String currentPassword, String newPassword,
                                       String securityQuestion, String securityAnswer) {}

    // ---- staff ----
    public record StaffProjectView(String wbsCode, String projectName, LocalDate expiryDate, String status, BigDecimal allocationPercentage) {}
    public record HistoryRow(String id, int month, int year, BigDecimal hours) {}
    public record BookRequest(String memberId, Integer month, Integer year, BigDecimal hours) {}

    // ---- admin ----
    public record BookingView(Long bookingId, String wbsCode, String projectName, String memberId, String staffName,
                              BigDecimal hoursBooked, BigDecimal calculatedCost, int month, int year, boolean projectExpired) {}
    public record MemberRef(String memberId, String name) {}
    public record ProjectView(String wbsCode, String projectName, LocalDate expiryDate, BigDecimal amountAllotted,
                              BigDecimal amountAvailable, BigDecimal amountBooked, String status,
                              java.util.List<MemberRef> members) {}
    public record MembersRequest(java.util.List<String> memberIds) {}
    public record ProjectCreateRequest(String wbsCode, String projectName, LocalDate expiryDate, BigDecimal amountAllotted) {}
    public record ProjectUpdateRequest(String projectName, LocalDate expiryDate, BigDecimal amountAllotted) {}
    public record StaffView(String memberId, String name, BigDecimal totalAllocation) {}
    public record RateRow(String effectiveFrom, BigDecimal rate) {}
    public record BaseRateView(BigDecimal rate, java.util.List<RateRow> rateHistory) {}
    public record RateChangeRequest(String effectiveFrom, BigDecimal rate) {}
    public record PasswordRequest(String password) {}
    // ---- allocation (Member mapping page) ----
    /** One row of the employee list: the standing allocation total and what is still free. */
    public record AllocationSummary(String memberId, String name, BigDecimal typedHours, BigDecimal totalPercent,
                                    BigDecimal remainingPercent, String status,
                                    boolean fromDefault, boolean finalized) {}
    public record AllocationRow(String wbsCode, String projectName, boolean expired, BigDecimal percentage,
                                BigDecimal hours, BigDecimal rate, BigDecimal cost) {}
    public record MonthOption(int month, int year, BigDecimal typedHours, boolean finalized) {}
    public record AllocationDetail(String memberId, String name, int month, int year, BigDecimal typedHours,
                                   boolean finalized, BigDecimal rate, java.util.List<AllocationRow> rows,
                                   BigDecimal totalPercent, BigDecimal totalHours, BigDecimal totalCost,
                                   BigDecimal remainingPercent, BigDecimal remainingHours,
                                   java.util.List<MonthOption> months, java.util.List<StandingRow> standing) {}
    /** One project of the employee's standing (default) allocation: used when a month has no hours yet. */
    public record StandingRow(String wbsCode, String projectName, boolean expired, BigDecimal percentage) {}
    public record DefaultInput(String wbsCode, BigDecimal percentage) {}
    public record DefaultSaveRequest(java.util.List<DefaultInput> rows) {}
    public record AllocationInput(String wbsCode, BigDecimal hours) {}
    public record AllocationSaveRequest(Integer month, Integer year, Boolean applyToDefault, java.util.List<AllocationInput> rows) {}
    // ---- one-month close ----
    public record PeriodRequest(Integer month, Integer year, String reason) {}
    public record PeriodStatus(String period, boolean finalized, String lastAction, String doneBy,
                               java.time.LocalDateTime doneAt, String reason) {}
    public record CheckIssue(String memberId, String name, String type, String message) {}
    public record PeriodCheck(int month, int year, boolean finalized, int staffTotal, int staffWithHours,
                              int fullyAllocated, BigDecimal unassignedHours, java.util.List<CheckIssue> issues) {}
    // ---- hours and rates ----
    public record HoursRequest(Integer month, Integer year, BigDecimal hours) {}
    public record RatePreview(int bookings, java.util.List<String> months, java.util.List<String> lockedUnchanged,
                              BigDecimal costDifference, java.util.List<String> budgetProblems) {}
}
