import { useEffect, useState } from "react";
import { api } from "../../api";
import { Alert, Badge, Button, Modal, Td, Th, inputCls } from "../../components/ui";
import { errMsg, fmtMoney, fmtNum, monthName, r2 } from "../../utils";

const periodKey = (m, y) => `${y}-${String(m).padStart(2, "0")}`;
// Projects this employee has been added to (Projects tab > Members). Nothing else can be assigned.
const projectsOf = (projects, memberId) => projects.filter((p) => p.members?.some((m) => m.memberId === memberId));
const num = (v) => (v === "" || v === null || v === undefined ? 0 : Number(v));

/**
 * View, or Edit/Assign, one employee's allocation for a month.
 * - Month with hours: split the hours (hours and % move together).
 * - Month with no hours: the % can still be set (it is the employee's standing allocation, used when hours are
 *   added); the hours column is locked at 0 because there is nothing to split yet.
 */
export default function AllocationModal({ mode, staff, projects, period: initialPeriod = null, onClose, onDone }) {
  const mine = projectsOf(projects, staff.memberId);
  return <Allocation mode={mode} staff={staff} projects={mine} initialPeriod={initialPeriod} onClose={onClose} onDone={onDone} />;
}

// ---------------------------------------------------------------- view / edit
function Allocation({ mode, staff, projects, initialPeriod, onClose, onDone }) {
  const [period, setPeriod] = useState(initialPeriod); // { month, year } or null = latest month with hours
  const [detail, setDetail] = useState(null);
  const [rows, setRows] = useState([]);
  const [applyDefault, setApplyDefault] = useState(false);
  const [addWbs, setAddWbs] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    let stale = false;
    setLoading(true);
    api
      .adminAllocation(staff.memberId, period ? { month: period.month, year: period.year } : {})
      .then((d) => {
        if (stale) return;
        setDetail(d);
        setRows(
          d.typedHours == null
            ? d.standing.map((r) => ({ wbsCode: r.wbsCode, projectName: r.projectName, expired: r.expired, hours: "0", pct: String(r.percentage) }))
            : d.rows.map((r) => ({ wbsCode: r.wbsCode, projectName: r.projectName, expired: r.expired, hours: String(r.hours), pct: String(r.percentage) })),
        );
        const latest = d.months[0];
        setApplyDefault(!!latest && latest.month === d.month && latest.year === d.year); // default: only for the latest month
        setError("");
      })
      .catch((e) => !stale && setError(errMsg(e)))
      .finally(() => !stale && setLoading(false));
    return () => {
      stale = true;
    };
  }, [staff.memberId, period]);

  const typed = detail?.typedHours == null ? 0 : Number(detail.typedHours);
  const noHours = !!detail && detail.typedHours == null;
  const editable = mode === "edit" && !!detail && (noHours || !detail.finalized);

  // % and hours move together: typing one recalculates the other.
  const setPct = (i, v) =>
    setRows((rs) => rs.map((r, k) => (k === i ? { ...r, pct: v, hours: v === "" ? "" : String(r2((typed * num(v)) / 100)) } : r)));
  const setHours = (i, v) =>
    setRows((rs) => rs.map((r, k) => (k === i ? { ...r, hours: v, pct: v === "" || typed === 0 ? "" : String(r2((num(v) / typed) * 100)) } : r)));
  const removeRow = (i) => setRows((rs) => rs.filter((_, k) => k !== i));
  const addRow = (wbsCode) => {
    const p = projects.find((x) => x.wbsCode === wbsCode);
    if (!p) return;
    setRows((rs) => [...rs, { wbsCode, projectName: p.projectName, expired: p.status === "Expired", hours: "0", pct: "0" }]);
    setAddWbs("");
  };

  const totalPct = r2(rows.reduce((s, r) => s + num(r.pct), 0));
  const totalHours = r2(rows.reduce((s, r) => s + num(r.hours), 0));
  const remPct = r2(100 - totalPct);
  const remHours = r2(typed - totalHours);
  const negative = rows.some((r) => num(r.pct) < 0 || num(r.hours) < 0);
  const over = totalPct > 100.0001 || (!noHours && totalHours > typed + 0.0001);
  const hasExpired = rows.some((r) => r.expired);

  const save = async () => {
    setBusy(true);
    setError("");
    try {
      const res = noHours
        ? await api.saveDefaultAllocation(staff.memberId, { rows: rows.map((r) => ({ wbsCode: r.wbsCode, percentage: num(r.pct) })) })
        : await api.saveAllocation(staff.memberId, {
            month: detail.month,
            year: detail.year,
            applyToDefault: applyDefault,
            rows: rows.map((r) => ({ wbsCode: r.wbsCode, hours: num(r.hours) })),
          });
      onDone(res.message);
    } catch (err) {
      setError(errMsg(err));
      setBusy(false);
    }
  };

  const unused = projects.filter((p) => !rows.some((r) => r.wbsCode === p.wbsCode));

  return (
    <Modal wide title={`${mode === "edit" ? "Edit/Assign" : "View"} allocation: ${staff.name} (${staff.memberId})`} onClose={onClose}>
      {loading && !detail ? (
        <p className="text-sm text-slate-500">Loading...</p>
      ) : (
        detail && (
          <div className="space-y-4">
            <div className="flex flex-wrap items-end justify-between gap-3">
              <div className="flex flex-wrap items-end gap-4">
                <label className="block text-sm font-medium text-slate-700">
                  <span className="mb-1.5 block">Month</span>
                  <select
                    className={`${inputCls} w-48 py-1.5`}
                    value={periodKey(detail.month, detail.year)}
                    onChange={(e) => {
                      const [y, m] = e.target.value.split("-");
                      setPeriod({ month: Number(m), year: Number(y) });
                    }}
                  >
                    {!detail.months.some((m) => m.month === detail.month && m.year === detail.year) && (
                      <option value={periodKey(detail.month, detail.year)}>{monthName(detail.month)} {detail.year} (no hours)</option>
                    )}
                    {detail.months.map((m) => (
                      <option key={periodKey(m.month, m.year)} value={periodKey(m.month, m.year)}>
                        {monthName(m.month)} {m.year}{m.finalized ? " (final)" : ""}
                      </option>
                    ))}
                  </select>
                </label>
                <p className="pb-1.5 text-sm text-slate-700">
                  Hours booked: <strong>{detail.typedHours == null ? "none" : fmtNum(detail.typedHours)}</strong>
                  {detail.rate != null && <span className="ml-3 text-slate-500">Rate {fmtMoney(detail.rate)} / h</span>}
                </p>
              </div>
              {detail.finalized && <Badge tone="amber">Finalized, read-only</Badge>}
            </div>

            {noHours && (
              <p className="rounded-lg border border-amber-200 bg-amber-50 px-4 py-2.5 text-sm text-amber-900">
                No hours are entered for {monthName(detail.month)} {detail.year}.{" "}
                {editable
                  ? "You can set the allocation % now (it is used when hours are added). Hours cannot be split until hours are entered."
                  : "This is the default allocation that will be used when hours are added."}
              </p>
            )}
            {mode === "edit" && detail.finalized && !noHours && (
              <Alert>This month was finalized by the manager. Hours and costs can no longer be changed.</Alert>
            )}
            {editable && projects.length === 0 && (
              <Alert>{staff.name} is not a member of any project yet. Add them to a project in the Projects tab (Members) first.</Alert>
            )}
            {editable && hasExpired && (
              <p className="rounded-lg border border-amber-200 bg-amber-50 px-4 py-2.5 text-sm text-amber-900">
                Some projects have expired. Give their share to current projects, then set the expired ones to 0 or remove them.
              </p>
            )}

            <div className="overflow-x-auto rounded-lg border border-slate-200">
              <table className="w-full text-left text-sm">
                <thead className="border-b border-slate-200 bg-slate-50">
                  <tr>
                    <Th>Sl No</Th>
                    <Th>WBS code</Th>
                    <Th>Project name</Th>
                    <Th right>Allocation %</Th>
                    <Th right>Hours split</Th>
                    {!editable && <Th right>Cost</Th>}
                    {editable && <Th right>{" "}</Th>}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {rows.length === 0 ? (
                    <tr><td colSpan={6} className="px-5 py-6 text-center text-slate-500">{noHours ? "No project is allocated yet." : "No project has a share of this month yet."}</td></tr>
                  ) : (
                    rows.map((r, i) => {
                      const live = detail.rows.find((x) => x.wbsCode === r.wbsCode);
                      return (
                        <tr key={r.wbsCode}>
                          <Td>{i + 1}</Td>
                          <Td strong>{r.wbsCode}</Td>
                          <Td>{r.projectName} {r.expired && <Badge tone="red">Expired</Badge>}</Td>
                          <Td right>
                            {editable ? (
                              <input type="number" min="0" max="100" step="0.01" aria-label={`Percentage for ${r.wbsCode}`} className={`${inputCls} ml-auto w-28 py-1.5 text-right`} value={r.pct} onChange={(e) => setPct(i, e.target.value)} />
                            ) : (
                              `${fmtNum(r.pct)}%`
                            )}
                          </Td>
                          <Td right>
                            {editable ? (
                              <input type="number" min="0" step="0.01" aria-label={`Hours for ${r.wbsCode}`} className={`${inputCls} ml-auto w-28 py-1.5 text-right`} value={r.hours} disabled={noHours} title={noHours ? "Enter the employee's hours first" : undefined} onChange={(e) => setHours(i, e.target.value)} />
                            ) : (
                              fmtNum(r.hours)
                            )}
                          </Td>
                          {!editable && <Td right>{live ? fmtMoney(live.cost) : ""}</Td>}
                          {editable && (
                            <Td right>
                              <Button small variant="ghost" className="!text-red-600 hover:!bg-red-50" onClick={() => removeRow(i)}>Remove</Button>
                            </Td>
                          )}
                        </tr>
                      );
                    })
                  )}
                </tbody>
                <tfoot className="border-t border-slate-200 bg-slate-50 text-sm">
                  <tr className="font-medium text-slate-800">
                    <td className="px-5 py-2.5" colSpan={3}>Total</td>
                    <td className="px-5 py-2.5 text-right">{fmtNum(totalPct)}%</td>
                    <td className="px-5 py-2.5 text-right">{fmtNum(totalHours)}</td>
                    <td className="px-5 py-2.5 text-right">{!editable && fmtMoney(detail.totalCost)}</td>
                  </tr>
                  <tr className={remPct < -0.0001 || remHours < -0.0001 ? "font-medium text-red-700" : "text-slate-600"}>
                    <td className="px-5 py-2.5" colSpan={3}>Remaining</td>
                    <td className="px-5 py-2.5 text-right">{fmtNum(remPct)}%</td>
                    <td className="px-5 py-2.5 text-right">{detail.typedHours == null ? "" : fmtNum(remHours)}</td>
                    <td />
                  </tr>
                </tfoot>
              </table>
            </div>

            {editable && (
              <>
                <div className="flex flex-wrap items-end gap-3">
                  <label className="block text-sm font-medium text-slate-700">
                    <span className="mb-1.5 block">Add a project to this month</span>
                    <select className={`${inputCls} w-72 py-1.5`} value={addWbs} onChange={(e) => addRow(e.target.value)} disabled={unused.length === 0}>
                      <option value="">Select project</option>
                      {unused.map((p) => (
                        <option key={p.wbsCode} value={p.wbsCode}>{p.wbsCode} - {p.projectName}{p.status === "Expired" ? " (expired)" : ""}</option>
                      ))}
                    </select>
                  </label>
                </div>
                {!noHours && (
                  <label className="flex items-start gap-2 text-sm text-slate-700">
                    <input type="checkbox" className="mt-1" checked={applyDefault} onChange={(e) => setApplyDefault(e.target.checked)} />
                    <span>Use this split for months {staff.name} submits from now on (updates the default allocation).</span>
                  </label>
                )}
                {over && <Alert>The total cannot go above 100% ({fmtNum(typed)} hours). Reduce a row first.</Alert>}
                {negative && <Alert>Percentages and hours cannot be negative.</Alert>}
              </>
            )}

            <Alert>{error}</Alert>
            <div className="flex justify-end gap-3">
              <Button variant="secondary" onClick={onClose}>{editable ? "Cancel" : "Close"}</Button>
              {editable && (
                <Button onClick={save} disabled={busy || over || negative}>{busy ? "Saving..." : "Save allocation"}</Button>
              )}
            </div>
          </div>
        )
      )}
    </Modal>
  );
}
