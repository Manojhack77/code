import { useCallback, useEffect, useState } from "react";
import { api } from "../../api";
import { Alert, Button, Modal, inputCls } from "../../components/ui";
import { errMsg, fmtNum, periodLabel } from "../../utils";
import AllocationModal from "./AllocationModal";

const key = (m, y) => `${y}-${String(m).padStart(2, "0")}`;

/** Checks the month before it is finalized. Warnings only: the manager can fix things here or finalize anyway. */
export default function FinalizeModal({ month, year, projects, onClose, onDone, onChanged }) {
  const [check, setCheck] = useState(null);
  const [note, setNote] = useState("");
  const [editing, setEditing] = useState(null); // { memberId, name }
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    try {
      setCheck(await api.periodCheck({ month, year }));
    } catch (e) {
      setError(errMsg(e));
    }
  }, [month, year]);

  useEffect(() => {
    load();
  }, [load]);

  const finalize = async () => {
    setBusy(true);
    setError("");
    try {
      const res = await api.finalizePeriod({ month, year, reason: note });
      onDone(res.message);
    } catch (e) {
      setError(errMsg(e));
      setBusy(false);
    }
  };

  const problems = check?.issues.filter((i) => i.type !== "NO_HOURS") ?? [];
  const noHours = check?.issues.filter((i) => i.type === "NO_HOURS") ?? [];
  const clean = check && check.issues.length === 0;

  return (
    <>
      <Modal wide title={`Finalize ${periodLabel(key(month, year))}`} onClose={onClose}>
        {!check ? (
          <p className="text-sm text-slate-500">{error || "Checking allocations..."}</p>
        ) : (
          <div className="space-y-4">
            <p className="text-sm text-slate-700">
              {check.staffWithHours} of {check.staffTotal} staff submitted hours. {check.fullyAllocated} are 100% allocated
              {Number(check.unassignedHours) > 0 && <>, <strong>{fmtNum(check.unassignedHours)} hours</strong> are not assigned to any project</>}.
            </p>

            {clean && (
              <p className="rounded-lg border border-emerald-200 bg-emerald-50 px-4 py-2.5 text-sm text-emerald-800">
                Everything is 100% allocated. Nothing needs fixing.
              </p>
            )}

            {problems.length > 0 && (
              <div className="rounded-lg border border-amber-200 bg-amber-50 p-4 text-sm text-amber-900">
                <p className="mb-2 font-medium">Check before finalizing</p>
                <ul className="space-y-2">
                  {problems.map((i, n) => (
                    <li key={`${i.memberId}-${n}`} className="flex flex-wrap items-center justify-between gap-2">
                      <span><strong>{i.name}</strong> ({i.memberId}): {i.message}</span>
                      <Button small variant="secondary" onClick={() => setEditing({ memberId: i.memberId, name: i.name })}>Edit/Assign</Button>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {noHours.length > 0 && (
              <div className="rounded-lg border border-slate-200 bg-slate-50 p-4 text-sm text-slate-700">
                <p className="mb-1 font-medium">No hours for this month</p>
                <p>{noHours.map((i) => `${i.name} (${i.memberId})`).join(", ")}. Add their hours in the table, or finalize without them.</p>
              </div>
            )}

            <label className="block text-sm font-medium text-slate-700">
              <span className="mb-1.5 block">Note (optional)</span>
              <input className={inputCls} value={note} maxLength={300} onChange={(e) => setNote(e.target.value)} placeholder="For the record, e.g. agreed with finance" />
            </label>

            <p className="text-sm text-slate-600">
              After finalizing, nobody can change this month's hours, percentages or costs, and staff cannot submit hours for it.
              You can reopen it later if something must be corrected.
            </p>
            <Alert>{error}</Alert>
            <div className="flex justify-end gap-3">
              <Button variant="secondary" onClick={onClose}>{clean ? "Cancel" : "Go back and edit"}</Button>
              <Button onClick={finalize} disabled={busy}>{busy ? "Finalizing..." : clean ? "Finalize" : "Finalize anyway"}</Button>
            </div>
          </div>
        )}
      </Modal>

      {editing && (
        <AllocationModal
          mode="edit"
          staff={{ memberId: editing.memberId, name: editing.name, remainingPercent: 0 }}
          projects={projects}
          period={{ month, year }}
          onClose={() => setEditing(null)}
          onDone={async () => {
            setEditing(null);
            await load();
            onChanged();
          }}
        />
      )}
    </>
  );
}
