import { useCallback, useEffect, useState } from "react";
import { api } from "../../api";
import { Alert, Badge, Button, Card, EmptyRow, Field, Modal, Td, Th, inputCls } from "../../components/ui";
import { MONTHS, errMsg, fmtMoney, periodLabel } from "../../utils";

const BASE_FROM = "2000-01";
const thisYear = new Date().getFullYear();
const YEARS = Array.from({ length: 8 }, (_, i) => thisYear - 2 + i);

const fmtFrom = (ym) => {
  if (ym === BASE_FROM) return "Starting rate";
  const [y, m] = ym.split("-").map(Number);
  return `From ${MONTHS[m - 1]} ${y}`;
};

// One base hourly rate for every staff member. A booking for a month is priced with the rate in force
// for that month; hours already booked keep the rate they were priced at.
export default function RatesTab() {
  const [base, setBase] = useState(null);
  const [staff, setStaff] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [busy, setBusy] = useState(false);
  const now = new Date();
  const [month, setMonth] = useState(now.getMonth() + 1);
  const [year, setYear] = useState(now.getFullYear());
  const [rate, setRate] = useState("");
  const [editKey, setEditKey] = useState(null); // effectiveFrom of the row being edited
  const [editVal, setEditVal] = useState("");
  const [resetFor, setResetFor] = useState(null);
  const [newPass, setNewPass] = useState("");

  const load = useCallback(async () => {
    try {
      const [b, s] = await Promise.all([api.adminBaseRate(), api.adminStaff()]);
      setBase(b);
      setStaff(s);
    } catch (e) {
      setError(errMsg(e));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const pickYear = (y) => setYear(y);
  const currentKey = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;
  const inForce = base?.rateHistory.find((h) => h.effectiveFrom <= currentKey)?.effectiveFrom;

  const [pending, setPending] = useState(null); // { effectiveFrom, rate (number, or null = remove), preview }

  // Open months that fall under the changed rate are recalculated; finalized months never change.
  // The preview shows what would happen first. Nothing is saved until it is confirmed (or nothing would change).
  const applyChange = async ({ effectiveFrom, rate: newRate }) => {
    setBusy(true);
    try {
      const res = newRate === null ? await api.deleteRateChange(effectiveFrom) : await api.addRateChange({ effectiveFrom, rate: newRate });
      setNotice(res.message);
      setRate("");
      setEditKey(null);
      await load();
    } catch (err) {
      setError(errMsg(err));
    } finally {
      setPending(null);
      setBusy(false);
    }
  };
  const requestChange = async (effectiveFrom, newRate) => {
    setBusy(true);
    setError("");
    setNotice("");
    try {
      const preview = await api.previewRateChange({ effectiveFrom, rate: newRate });
      if (preview.bookings === 0 && preview.lockedUnchanged.length === 0 && preview.budgetProblems.length === 0) {
        setBusy(false);
        await applyChange({ effectiveFrom, rate: newRate });
      } else {
        setPending({ effectiveFrom, rate: newRate, preview });
        setBusy(false);
      }
    } catch (err) {
      setError(errMsg(err));
      setBusy(false);
    }
  };
  const saveRate = (e) => {
    e.preventDefault();
    if (!(Number(rate) > 0)) return setError("Rate must be greater than zero.");
    requestChange(`${year}-${String(month).padStart(2, "0")}`, Number(rate));
  };
  const saveEdit = () => {
    if (!(Number(editVal) > 0)) return setError("Rate must be greater than zero.");
    requestChange(editKey, Number(editVal));
  };
  const removeChange = (h) => requestChange(h.effectiveFrom, null);

  const resetPassword = async () => {
    if (newPass.length < 6) return setError("Password must be at least 6 characters.");
    try {
      await api.adminResetPassword(resetFor.memberId, newPass);
      setNotice(`Password for ${resetFor.name} was reset. Share the new password with them in person.`);
      setError("");
      setResetFor(null);
      setNewPass("");
    } catch (err) {
      setError(errMsg(err));
    }
  };

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-xl font-semibold text-slate-800">Base rate and staff</h2>
        <p className="mt-1 text-sm text-slate-500">One hourly rate applies to all staff. Staff cannot see rates.</p>
      </div>

      <div className="space-y-2">
        <Alert>{error}</Alert>
        <Alert type="success">{notice}</Alert>
      </div>

      {pending && (
        <Modal title={pending.rate === null ? "Remove this rate?" : "Save this rate?"} onClose={() => setPending(null)}>
          <div className="space-y-3 text-sm text-slate-700">
            <p>
              {pending.rate === null ? `Remove the rate that starts ${fmtFrom(pending.effectiveFrom).toLowerCase()}.` : `${fmtMoney(pending.rate)} per hour, ${fmtFrom(pending.effectiveFrom).toLowerCase()}.`}
            </p>
            {pending.preview.bookings > 0 ? (
              <p>
                <strong>{pending.preview.bookings} booking(s)</strong> in {pending.preview.months.map(periodLabel).join(", ")} will be recalculated.
                Total cost changes by <strong>{pending.preview.costDifference >= 0 ? "+" : ""}{fmtMoney(pending.preview.costDifference)}</strong>.
              </p>
            ) : (
              <p>No existing booking in an open month changes.</p>
            )}
            {pending.preview.lockedUnchanged.length > 0 && (
              <p className="text-slate-600">Finalized months that keep their old rate: {pending.preview.lockedUnchanged.map(periodLabel).join(", ")}.</p>
            )}
            {pending.preview.budgetProblems.length > 0 && (
              <div className="rounded-lg border border-red-200 bg-red-50 px-4 py-2.5 text-red-800">
                <p className="font-medium">A project budget is too small for this rate:</p>
                <ul className="mt-1 list-disc pl-5">{pending.preview.budgetProblems.map((m) => <li key={m}>{m}</li>)}</ul>
                <p className="mt-1">Raise the budget on the Projects tab first.</p>
              </div>
            )}
          </div>
          <div className="mt-5 flex justify-end gap-3">
            <Button variant="secondary" onClick={() => setPending(null)}>Cancel</Button>
            <Button onClick={() => applyChange(pending)} disabled={busy || pending.preview.budgetProblems.length > 0}>
              {busy ? "Saving..." : pending.rate === null ? "Remove" : "Save and recalculate"}
            </Button>
          </div>
        </Modal>
      )}

      <section>
        <h3 className="mb-3 font-semibold text-slate-800">Base rate per hour</h3>
        <Card className="p-6">
          <p className="text-3xl font-semibold text-slate-800">{loading ? "..." : fmtMoney(base?.rate)}</p>
          <p className="mt-1 text-sm text-slate-500">Current rate for all staff</p>

          <form onSubmit={saveRate} noValidate className="mt-6 grid max-w-xl grid-cols-2 items-end gap-3 sm:grid-cols-4">
            <Field label="New rate (₹/h)">
              <input type="number" min="0" step="0.01" className={inputCls} value={rate} onChange={(e) => setRate(e.target.value)} />
            </Field>
            <Field label="Starts in">
              <select className={inputCls} value={month} onChange={(e) => setMonth(Number(e.target.value))}>
                {MONTHS.map((m, i) => <option key={m} value={i + 1}>{m}</option>)}
              </select>
            </Field>
            <Field label="Year">
              <select className={inputCls} value={year} onChange={(e) => pickYear(Number(e.target.value))}>
                {YEARS.map((y) => <option key={y} value={y}>{y}</option>)}
              </select>
            </Field>
            <Button type="submit" disabled={busy}>{busy ? "Saving..." : "Change rate"}</Button>
          </form>
          <p className="mt-3 text-xs text-slate-500">
            A rate can start in any month that is not finalized, including a past one. Bookings already made in the open months it covers are recalculated
            (you see a preview first). Finalized months never change.
          </p>
        </Card>

        <Card className="mt-4 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="border-b border-slate-200 bg-slate-50">
                <tr>
                  <Th>Sl No</Th>
                  <Th>Rate history</Th>
                  <Th>Rate per hour</Th>
                  <Th right>Action</Th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {loading ? (
                  <EmptyRow cols={4}>Loading...</EmptyRow>
                ) : (
                  base.rateHistory.map((h, idx) => (
                    <tr key={h.effectiveFrom} className="hover:bg-slate-50">
                      <Td>{idx + 1}</Td>
                      <Td strong>
                        {fmtFrom(h.effectiveFrom)}
                        {h.effectiveFrom === inForce && <span className="ml-2"><Badge tone="green">Current</Badge></span>}
                        {h.effectiveFrom > currentKey && <span className="ml-2"><Badge tone="amber">Upcoming</Badge></span>}
                      </Td>
                      <Td>
                        {editKey === h.effectiveFrom ? (
                          <input type="number" min="0" step="0.01" aria-label="Rate per hour" autoFocus className={`${inputCls} w-32 py-1.5`}
                            value={editVal} onChange={(e) => setEditVal(e.target.value)}
                            onKeyDown={(e) => { if (e.key === "Enter") saveEdit(); if (e.key === "Escape") setEditKey(null); }} />
                        ) : (
                          fmtMoney(h.rate)
                        )}
                      </Td>
                      <Td right>
                        {editKey === h.effectiveFrom ? (
                          <span className="inline-flex gap-2">
                            <Button small onClick={saveEdit}>Save</Button>
                            <Button small variant="secondary" onClick={() => setEditKey(null)}>Cancel</Button>
                          </span>
                        ) : (
                          <span className="inline-flex gap-1">
                            <Button small variant="ghost" onClick={() => { setEditKey(h.effectiveFrom); setEditVal(String(h.rate)); setError(""); setNotice(""); }}>Edit</Button>
                            {h.effectiveFrom !== BASE_FROM && (
                              <Button small variant="ghost" className="!text-red-600 hover:!bg-red-50" onClick={() => removeChange(h)}>Remove</Button>
                            )}
                          </span>
                        )}
                      </Td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </Card>
      </section>

      <section>
        <h3 className="mb-3 font-semibold text-slate-800">Staff</h3>
        <Card className="overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="border-b border-slate-200 bg-slate-50">
                <tr>
                  <Th>Sl No</Th>
                  <Th>Staff</Th>
                  <Th right>Action</Th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {loading ? (
                  <EmptyRow cols={3}>Loading...</EmptyRow>
                ) : staff.length === 0 ? (
                  <EmptyRow cols={3}>No staff yet. Staff appear here after they sign up.</EmptyRow>
                ) : (
                  staff.map((s, idx) => (
                    <tr key={s.memberId} className="hover:bg-slate-50">
                      <Td>{idx + 1}</Td>
                      <Td strong>{s.name} <span className="font-normal text-slate-500">({s.memberId})</span></Td>
                      <Td right>
                        <Button small variant="ghost" onClick={() => { setResetFor(s); setNewPass(""); setError(""); }}>Reset password</Button>
                      </Td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </Card>
      </section>

      {resetFor && (
        <Modal title={`Reset password for ${resetFor.name}`} onClose={() => setResetFor(null)}>
          <div className="space-y-4">
            <Field label="New password" hint="At least 6 characters. Tell the staff member in person.">
              <input className={inputCls} value={newPass} autoFocus onChange={(e) => setNewPass(e.target.value)} />
            </Field>
            <div className="flex justify-end gap-3">
              <Button variant="secondary" onClick={() => setResetFor(null)}>Cancel</Button>
              <Button onClick={resetPassword}>Reset password</Button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}
