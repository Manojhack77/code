import axios from "axios";
import { API_URL } from "../config";

// The login session (JWT) is kept in sessionStorage: it survives a page refresh and is
// cleared automatically when the browser tab is closed. Nothing else is saved in the browser.
const KEY = "mhb_session";
let session = null;
try {
  session = JSON.parse(sessionStorage.getItem(KEY));
} catch {
  session = null;
}
export const getSession = () => session;
export const setSession = (s) => {
  session = s;
  sessionStorage.setItem(KEY, JSON.stringify(s));
};
export const clearSession = () => {
  session = null;
  sessionStorage.removeItem(KEY);
};

const http = axios.create({ baseURL: API_URL });

http.interceptors.request.use((cfg) => {
  if (session?.token) cfg.headers.Authorization = `Bearer ${session.token}`;
  return cfg;
});

http.interceptors.response.use(
  (r) => r,
  (e) => {
    // Expired / invalid token on a protected call -> back to login.
    if (e.response?.status === 401 && !e.config?.url?.includes("/api/auth/")) {
      clearSession();
      window.location.assign("/login");
    }
    return Promise.reject(e);
  },
);

const data = (p) => p.then((r) => r.data);

// Endpoint paths follow the spec; see API_CONTRACT.md for the full list.
export const api = {
  login: (b) => data(http.post("/api/auth/login", b)),
  signup: (b) => data(http.post("/api/auth/signup", b)),
  forgotQuestion: (b) => data(http.post("/api/auth/forgot/question", b)),
  forgotReset: (b) => data(http.post("/api/auth/forgot/reset", b)),

  myProfile: () => data(http.get("/api/me")),
  updateProfile: (b) => data(http.put("/api/me", b)),

  staffProjects: (memberId) => data(http.get(`/api/staff/projects/${memberId}`)),
  staffHistory: (memberId) => data(http.get(`/api/staff/history/${memberId}`)),
  bookHours: (b) => data(http.post("/api/staff/book", b)),
  updateHours: ({ id, hours }) =>
    data(http.patch(`/api/staff/update-hours/${id}`, null, { params: { hours } })),

  adminBookings: (params) => data(http.get("/api/admin/bookings", { params })),
  adminProjects: () => data(http.get("/api/admin/projects")),
  createProject: (b) => data(http.post("/api/admin/projects", b)),
  updateProject: (wbs, b) => data(http.put(`/api/admin/projects/${wbs}`, b)),
  setProjectMembers: (wbs, memberIds) => data(http.put(`/api/admin/projects/${wbs}/members`, { memberIds })),
  deleteProject: (wbs) => data(http.delete(`/api/admin/projects/${wbs}`)),
  adminStaff: () => data(http.get("/api/admin/staff")),
  adminResetPassword: (memberId, password) =>
    data(http.put(`/api/admin/staff/${memberId}/password`, { password })),
  adminBaseRate: () => data(http.get("/api/admin/base-rate")),
  addRateChange: (b) => data(http.post("/api/admin/base-rate/changes", b)),
  deleteRateChange: (effectiveFrom) => data(http.delete(`/api/admin/base-rate/changes/${effectiveFrom}`)),
  adminAllocations: (params) => data(http.get("/api/admin/allocations", { params })),
  adminAllocation: (memberId, params) => data(http.get(`/api/admin/allocations/${memberId}`, { params })),
  saveAllocation: (memberId, b) => data(http.put(`/api/admin/allocations/${memberId}`, b)),
  saveDefaultAllocation: (memberId, b) => data(http.put(`/api/admin/allocations/${memberId}/default`, b)),
  periodStatus: (params) => data(http.get("/api/admin/periods/status", { params })),
  periodCheck: (params) => data(http.get("/api/admin/periods/check", { params })),
  finalizePeriod: (b) => data(http.post("/api/admin/periods/finalize", b)),
  reopenPeriod: (b) => data(http.post("/api/admin/periods/reopen", b)),
  setMonthHours: (memberId, b) => data(http.put(`/api/admin/allocations/${memberId}/hours`, b)),
  previewRateChange: (b) => data(http.post("/api/admin/base-rate/preview", b)),
};
