import { createContext, useContext, useState } from "react";
import { api, clearSession, getSession, setSession } from "../api";

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [auth, setAuth] = useState(getSession);

  const persist = (res) => {
    setSession(res); // saved in sessionStorage so a refresh keeps you logged in
    setAuth(res);
    return res.user;
  };

  const login = async (userId, password) => persist(await api.login({ userId, password }));
  // Signing up does not log you in: you are sent to the login page to sign in with the new account.
  const signup = (form) => api.signup(form);
  // After the user edits their profile, keep the name shown in the header (and the saved session) current.
  const updateUser = (changes) => persist({ ...auth, user: { ...auth.user, ...changes } });
  const logout = () => {
    clearSession();
    setAuth(null);
  };

  return (
    <AuthContext.Provider value={{ user: auth?.user ?? null, login, signup, updateUser, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
