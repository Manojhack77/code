export const MONTHS = [
  "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December",
];

export const monthName = (m) => MONTHS[Number(m) - 1] ?? "";

export const fmtMoney = (n) =>
  new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 2,
  }).format(Number(n) || 0);

export const errMsg = (e) =>
  e?.response?.data?.message || e?.message || "Something went wrong. Please try again.";

// Offline "clue" questions used to recover a forgotten password (no email in this system).
export const SECURITY_QUESTIONS = [
  "What was the name of your first school?",
  "What is your mother's first name?",
  "In which town were you born?",
  "What was the name of your first pet?",
  "What is your favourite teacher's name?",
];

export const r2 = (n) => Math.round((Number(n) + Number.EPSILON) * 100) / 100;
/** 62.5 -> "62.5", 60 -> "60", 23.125 -> "23.13" (no trailing zeros). */
export const fmtNum = (n) => (n === null || n === undefined || n === "" ? "" : String(r2(n)));
export const periodLabel = (key) => {
  const [y, m] = String(key).split("-");
  return `${monthName(Number(m))} ${y}`;
};
export const fmtDateTime = (iso) =>
  iso ? new Date(iso).toLocaleString("en-IN", { dateStyle: "medium", timeStyle: "short" }) : "";

/** Sort helper: A-Z by name, ignoring case. */
export const byName = (a, b) => a.name.localeCompare(b.name, undefined, { sensitivity: "base" });
