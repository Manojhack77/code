import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import ProfileModal from "./ProfileModal";
import { Button } from "./ui";

export default function AppShell({ children }) {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [editingProfile, setEditingProfile] = useState(false);

  const handleLogout = () => {
    logout();
    navigate("/login", { replace: true });
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <header className="border-b border-slate-200 bg-white">
        <div className="mx-auto flex max-w-[96rem] items-center justify-between gap-4 px-6 py-3.5">
          <p className="text-base font-semibold text-slate-800">ManHourBooking</p>
          <div className="flex items-center gap-4">
            <p className="text-sm text-slate-600">
              {user.role === "ADMIN" ? "Administrator" : "Welcome"}, <span className="font-medium text-slate-800">{user.name}</span>
              <span className="mx-2 text-slate-300">|</span>
              ID: {user.memberId}
            </p>
            <Button variant="secondary" small onClick={() => setEditingProfile(true)}>
              Edit profile
            </Button>
            <Button variant="secondary" small onClick={handleLogout}>
              Log out
            </Button>
          </div>
        </div>
      </header>
      <main className="mx-auto max-w-[96rem] px-6 py-8">{children}</main>
      {editingProfile && <ProfileModal onClose={() => setEditingProfile(false)} />}
    </div>
  );
}
