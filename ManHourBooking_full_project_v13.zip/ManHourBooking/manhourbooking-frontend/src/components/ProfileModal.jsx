import { useEffect, useState } from "react";
import { api } from "../api";
import { useAuth } from "../context/AuthContext";
import { SECURITY_QUESTIONS, errMsg } from "../utils";
import { Alert, Button, Field, Modal, inputCls } from "./ui";

/** Lets the logged-in user edit their own details. The ID and role cannot be changed. */
export default function ProfileModal({ onClose }) {
  const { user, updateUser } = useAuth();
  const [form, setForm] = useState({
    name: user.name, currentPassword: "", newPassword: "", confirm: "", securityQuestion: SECURITY_QUESTIONS[0], securityAnswer: "",
  });
  const [error, setError] = useState("");
  const [saved, setSaved] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    api
      .myProfile()
      .then((p) => p.securityQuestion && setForm((f) => ({ ...f, securityQuestion: p.securityQuestion })))
      .catch((e) => setError(errMsg(e)));
  }, []);

  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));
  const changing = form.newPassword || form.securityAnswer.trim();

  const save = async (e) => {
    e.preventDefault();
    if (!form.name.trim()) return setError("Name cannot be empty.");
    if (form.newPassword && form.newPassword.length < 6) return setError("New password must be at least 6 characters.");
    if (form.newPassword !== form.confirm) return setError("The new passwords do not match.");
    if (changing && !form.currentPassword) return setError("Enter your current password to change the password or clue.");
    setBusy(true);
    setError("");
    setSaved("");
    try {
      const p = await api.updateProfile({
        name: form.name.trim(),
        currentPassword: form.currentPassword || null,
        newPassword: form.newPassword || null,
        securityQuestion: form.securityQuestion,
        securityAnswer: form.securityAnswer.trim() || null,
      });
      updateUser({ name: p.name });
      setSaved("Your details were saved.");
      setForm((f) => ({ ...f, name: p.name, currentPassword: "", newPassword: "", confirm: "", securityAnswer: "" }));
    } catch (err) {
      setError(errMsg(err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <Modal title="My profile" onClose={onClose}>
      <form onSubmit={save} noValidate className="space-y-4">
        <Field label="User ID" hint="Your ID and role cannot be changed.">
          <input className={inputCls} value={user.memberId} disabled readOnly />
        </Field>
        <Field label="Full name">
          <input className={inputCls} value={form.name} onChange={set("name")} autoComplete="name" autoFocus />
        </Field>

        <p className="border-t border-slate-200 pt-3 text-sm font-medium text-slate-700">
          Change password or clue (optional). Leave blank to keep them.
        </p>
        <Field label="New password" hint="At least 6 characters.">
          <input type="password" className={inputCls} value={form.newPassword} onChange={set("newPassword")} autoComplete="new-password" />
        </Field>
        <Field label="Confirm new password">
          <input type="password" className={inputCls} value={form.confirm} onChange={set("confirm")} autoComplete="new-password" />
        </Field>
        <Field label="Clue question">
          <select className={inputCls} value={form.securityQuestion} onChange={set("securityQuestion")}>
            {[...new Set([form.securityQuestion, ...SECURITY_QUESTIONS])].map((q) => (
              <option key={q} value={q}>{q}</option>
            ))}
          </select>
        </Field>
        <Field label="New clue answer" hint="Fill this only if you want to change your clue.">
          <input className={inputCls} value={form.securityAnswer} onChange={set("securityAnswer")} autoComplete="off" />
        </Field>
        {changing && (
          <Field label="Current password" hint="Needed to change the password or the clue.">
            <input type="password" className={inputCls} value={form.currentPassword} onChange={set("currentPassword")} autoComplete="current-password" />
          </Field>
        )}

        <Alert>{error}</Alert>
        <Alert type="success">{saved}</Alert>
        <div className="flex justify-end gap-3">
          <Button type="button" variant="secondary" onClick={onClose}>Close</Button>
          <Button type="submit" disabled={busy}>{busy ? "Saving..." : "Save"}</Button>
        </div>
      </form>
    </Modal>
  );
}
