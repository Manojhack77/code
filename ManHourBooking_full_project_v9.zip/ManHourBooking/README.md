# ManHourBooking (full project)

manhourbooking-backend/   Spring Boot 3 + MySQL  (import into Eclipse as an existing Maven project)
manhourbooking-frontend/  React + Vite           (open in VS Code)

## Quick start
1. MySQL running; in MySQL Workbench run: CREATE DATABASE IF NOT EXISTS manhourbooking;
2. Backend: open manhourbooking-backend/src/main/resources/application.properties and set your MySQL
   username and password. Eclipse: File > Import > Maven > Existing Maven Projects, then right click
   ManHourBookingApplication.java > Run As > Java Application. Wait for "Started ManHourBookingApplication".
3. Frontend: in manhourbooking-frontend run `npm install` then `npm run dev`.
4. Open http://localhost:5173 and log in: ADMIN01 / admin123 (created by the backend on first start).

The frontend has no mock data and saves nothing in the browser; refreshing the page logs you out.
