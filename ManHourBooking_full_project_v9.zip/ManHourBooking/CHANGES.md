# What changed in this version

## Dashboard
- Delete option removed. Hour-editing option and its backend logic removed (dashboard is read-only).
- Added Employee ID column and a search box (employee ID, name, WBS, project).

## Member mapping (rebuilt)
- List: Employee ID, Employee name, Allocation (total, remaining, status), and View / Edit / Assign.
- Assign: pick a project and a percentage (cannot go above the employee's remaining %).
- View: pick a month; shows hours booked, WBS, project, allocation %, hours split, cost, total and remaining.
- Edit: same table with editable % and hours. Typing % recalculates hours; typing hours recalculates %. Total cannot go above 100%.
  Add or remove several projects in one save (this is how expired projects are reallocated). Cost and project budgets are recalculated.
- Old logic removed: reassign, remove mapping, per-row mapping list.

## Locking
- Project expiry no longer blocks bookings, assignments or budget changes (it is shown as a badge only).
- New lock: the manager finalizes a month (or a range). A finalized month can never change: staff booking/editing, allocation edits,
  assign back-fill and project deletion are all refused for it.

## Finalizing one month (on the Member mapping page, no Periods tab)
- Month / Year selector with an Open / Finalized chip. "Finalize month..." first checks the month: employees not 100% allocated,
  shares left on expired projects, staff with no hours. Each has an Edit button; you can go back and fix, or Finalize anyway.
- A finalized month is locked. "Reopen..." (with an optional reason) unlocks it so it can be edited, then finalize again.
  Every finalize and reopen is recorded (who, when, why).
- Removed: Periods tab, from/to dates, date-range finalize, "finalized so far" list, reports and printing.

## Total hours in the Member mapping table
- New Total hours column for the selected month: Add hours / Edit in the cell. Same record the employee sees; split, cost and budgets recalculate.

## Rates
- Adding, editing or removing a rate recalculates bookings in open months it covers (preview first). Finalized months never change.
  A rate can start in a past month if that month is open.

## Not touched
- pom.xml, package.json, package-lock.json are identical to your upload. No new libraries.

## One-time database note
- Percentages became decimals. On start-up SchemaFixer converts the two INT columns to DECIMAL(5,2) and carries months you already finalized into the new period_lock table; manual SQL is in the backend README.
