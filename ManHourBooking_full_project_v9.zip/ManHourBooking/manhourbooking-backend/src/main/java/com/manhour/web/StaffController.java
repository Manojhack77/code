package com.manhour.web;

import static com.manhour.dto.Dtos.*;

import com.manhour.security.AuthUser;
import com.manhour.service.StaffService;
import java.math.BigDecimal;
import java.util.List;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/staff")
public class StaffController {
    private final StaffService staff;

    public StaffController(StaffService staff) {
        this.staff = staff;
    }

    @GetMapping("/projects/{memberId}")
    public List<StaffProjectView> projects(@AuthenticationPrincipal AuthUser me, @PathVariable String memberId) {
        return staff.projects(me, memberId);
    }

    @GetMapping("/history/{memberId}")
    public List<HistoryRow> history(@AuthenticationPrincipal AuthUser me, @PathVariable String memberId) {
        return staff.history(me, memberId);
    }

    @PostMapping("/book")
    public MessageResponse book(@AuthenticationPrincipal AuthUser me, @RequestBody BookRequest r) {
        return staff.book(me, r);
    }

    /** STAFF only. Administrators change the split on the Member mapping page. */
    @PatchMapping("/update-hours/{id}")
    public MessageResponse update(@AuthenticationPrincipal AuthUser me, @PathVariable String id,
                                  @RequestParam BigDecimal hours) {
        return staff.updateHours(me, id, hours);
    }
}
