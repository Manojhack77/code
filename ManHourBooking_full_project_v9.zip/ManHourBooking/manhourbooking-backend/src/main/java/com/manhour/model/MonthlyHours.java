package com.manhour.model;

import jakarta.persistence.*;
import java.math.BigDecimal;

/**
 * The total hours a staff member typed for one month. This is what the staff member always sees.
 * Booking rows only hold the part of these hours that is assigned to projects (the mapped %),
 * so hours that are not mapped yet are kept here until an administrator maps them.
 */
@Entity
@Table(name = "monthly_hours",
        uniqueConstraints = @UniqueConstraint(columnNames = {"member_id", "month", "year"}))
public class MonthlyHours {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "member_id", nullable = false, length = 40)
    private String memberId;
    @Column(nullable = false)
    private int month;
    @Column(nullable = false)
    private int year;
    @Column(nullable = false, precision = 10, scale = 2)
    private BigDecimal totalHours;

    public Long getId() { return id; }
    public String getMemberId() { return memberId; }
    public void setMemberId(String memberId) { this.memberId = memberId; }
    public int getMonth() { return month; }
    public void setMonth(int month) { this.month = month; }
    public int getYear() { return year; }
    public void setYear(int year) { this.year = year; }
    public BigDecimal getTotalHours() { return totalHours; }
    public void setTotalHours(BigDecimal totalHours) { this.totalHours = totalHours; }
}
