package com.manhour.model;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
@Table(name = "project")
public class Project {
    @Id
    @Column(length = 40)
    private String wbsCode;
    @Column(nullable = false, length = 160)
    private String projectName;
    @Column(nullable = false)
    private LocalDate expiryDate;
    @Column(nullable = false, precision = 14, scale = 2)
    private BigDecimal amountAllotted;
    @Column(nullable = false, precision = 14, scale = 2)
    private BigDecimal amountBooked = BigDecimal.ZERO;
    @Column(nullable = false, precision = 14, scale = 2)
    private BigDecimal amountAvailable = BigDecimal.ZERO;

    public boolean isExpired() { return expiryDate.isBefore(LocalDate.now()); }

    public String getWbsCode() { return wbsCode; }
    public void setWbsCode(String wbsCode) { this.wbsCode = wbsCode; }
    public String getProjectName() { return projectName; }
    public void setProjectName(String projectName) { this.projectName = projectName; }
    public LocalDate getExpiryDate() { return expiryDate; }
    public void setExpiryDate(LocalDate expiryDate) { this.expiryDate = expiryDate; }
    public BigDecimal getAmountAllotted() { return amountAllotted; }
    public void setAmountAllotted(BigDecimal a) { this.amountAllotted = a; }
    public BigDecimal getAmountBooked() { return amountBooked; }
    public void setAmountBooked(BigDecimal a) { this.amountBooked = a; }
    public BigDecimal getAmountAvailable() { return amountAvailable; }
    public void setAmountAvailable(BigDecimal a) { this.amountAvailable = a; }
}
