package com.manhour.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.LocalDateTime;

/** Audit trail: every finalize and reopen of a month, with who, when and the reason. Never edited. */
@Entity
@Table(name = "period_event")
public class PeriodEvent {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "period_key", nullable = false, length = 7)
    private String periodKey;
    @Column(nullable = false, length = 12)
    private String action; // FINALIZED or REOPENED
    @Column(nullable = false, length = 160)
    private String doneBy;
    @Column(nullable = false)
    private LocalDateTime doneAt;
    @Column(length = 300)
    private String reason;

    public PeriodEvent() {}

    public PeriodEvent(String periodKey, String action, String doneBy, LocalDateTime doneAt, String reason) {
        this.periodKey = periodKey;
        this.action = action;
        this.doneBy = doneBy;
        this.doneAt = doneAt;
        this.reason = reason;
    }

    public Long getId() { return id; }
    public String getPeriodKey() { return periodKey; }
    public String getAction() { return action; }
    public String getDoneBy() { return doneBy; }
    public LocalDateTime getDoneAt() { return doneAt; }
    public String getReason() { return reason; }
}
