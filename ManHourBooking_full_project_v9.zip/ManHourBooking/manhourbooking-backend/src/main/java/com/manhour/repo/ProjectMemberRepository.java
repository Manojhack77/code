package com.manhour.repo;

import com.manhour.model.ProjectMember;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProjectMemberRepository extends JpaRepository<ProjectMember, Long> {
    List<ProjectMember> findByWbsCode(String wbsCode);
    boolean existsByWbsCodeAndMemberId(String wbsCode, String memberId);
    void deleteByWbsCode(String wbsCode);
}
