package com.manhour.model;

import jakarta.persistence.*;
import java.math.BigDecimal;

@Entity
@Table(name = "booking", indexes = @Index(columnList = "member_id, year, month"))
public class Booking {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long bookingId;
    @Column(name = "member_id", nullable = false, length = 40)
    private String memberId;
    @Column(name = "wbs_code", nullable = false, length = 40)
    private String wbsCode;
    @Column(nullable = false)
    private int month;
    @Column(nullable = false)
    private int year;
    @Column(nullable = false, precision = 10, scale = 2)
    private BigDecimal hoursBooked;
    /** Share of the month's hours this row holds (the mapping % when it was created). */
    @Column(nullable = false, precision = 5, scale = 2)
    private BigDecimal allocationPercentage = BigDecimal.ZERO;
    /** Rate in force when this row was priced; edits reuse it so history never changes. */
    @Column(nullable = false, precision = 12, scale = 2)
    private BigDecimal rateApplied;
    @Column(nullable = false, precision = 14, scale = 2)
    private BigDecimal calculatedCost;

    public Long getBookingId() { return bookingId; }
    public String getMemberId() { return memberId; }
    public void setMemberId(String memberId) { this.memberId = memberId; }
    public String getWbsCode() { return wbsCode; }
    public void setWbsCode(String wbsCode) { this.wbsCode = wbsCode; }
    public int getMonth() { return month; }
    public void setMonth(int month) { this.month = month; }
    public int getYear() { return year; }
    public void setYear(int year) { this.year = year; }
    public BigDecimal getAllocationPercentage() { return allocationPercentage; }
    public void setAllocationPercentage(BigDecimal p) { this.allocationPercentage = p; }
    public BigDecimal getHoursBooked() { return hoursBooked; }
    public void setHoursBooked(BigDecimal h) { this.hoursBooked = h; }
    public BigDecimal getRateApplied() { return rateApplied; }
    public void setRateApplied(BigDecimal r) { this.rateApplied = r; }
    public BigDecimal getCalculatedCost() { return calculatedCost; }
    public void setCalculatedCost(BigDecimal c) { this.calculatedCost = c; }
}
