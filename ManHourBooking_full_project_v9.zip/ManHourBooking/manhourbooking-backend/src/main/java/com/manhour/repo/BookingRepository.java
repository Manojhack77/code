package com.manhour.repo;

import com.manhour.model.Booking;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface BookingRepository extends JpaRepository<Booking, Long> {
    List<Booking> findByMemberId(String memberId);
    List<Booking> findByMemberIdAndMonthAndYear(String memberId, int month, int year);
    boolean existsByMemberIdAndMonthAndYear(String memberId, int month, int year);
    boolean existsByMemberIdAndWbsCodeAndMonthAndYear(String memberId, String wbsCode, int month, int year);
    boolean existsByWbsCode(String wbsCode);
    List<Booking> findByWbsCode(String wbsCode);
    long countByWbsCode(String wbsCode);
    void deleteByWbsCode(String wbsCode);

    @Query("select b from Booking b where (:month is null or b.month = :month) and (:year is null or b.year = :year) "
            + "order by b.year desc, b.month desc, b.wbsCode")
    List<Booking> search(@Param("month") Integer month, @Param("year") Integer year);
}
