package com.manhour.model;

import java.math.BigDecimal;
import jakarta.persistence.*;

@Entity
@Table(name = "project_member_mapping",
        uniqueConstraints = @UniqueConstraint(columnNames = {"member_id", "wbs_code"}))
public class ProjectMapping {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long mappingId;
    @Column(name = "member_id", nullable = false, length = 40)
    private String memberId;
    @Column(name = "wbs_code", nullable = false, length = 40)
    private String wbsCode;
    @Column(nullable = false, precision = 5, scale = 2)
    private BigDecimal allocationPercentage = BigDecimal.ZERO;

    public Long getMappingId() { return mappingId; }
    public String getMemberId() { return memberId; }
    public void setMemberId(String memberId) { this.memberId = memberId; }
    public String getWbsCode() { return wbsCode; }
    public void setWbsCode(String wbsCode) { this.wbsCode = wbsCode; }
    public BigDecimal getAllocationPercentage() { return allocationPercentage; }
    public void setAllocationPercentage(BigDecimal p) { this.allocationPercentage = p; }
}
