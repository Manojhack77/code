package com.manhour.model;

import jakarta.persistence.*;

/** "This staff member works on this project". Only members can be assigned to the project on Member mapping. */
@Entity
@Table(name = "project_member",
        uniqueConstraints = @UniqueConstraint(columnNames = {"wbs_code", "member_id"}))
public class ProjectMember {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "wbs_code", nullable = false, length = 40)
    private String wbsCode;
    @Column(name = "member_id", nullable = false, length = 40)
    private String memberId;

    public ProjectMember() {}

    public ProjectMember(String wbsCode, String memberId) {
        this.wbsCode = wbsCode;
        this.memberId = memberId;
    }

    public Long getId() { return id; }
    public String getWbsCode() { return wbsCode; }
    public void setWbsCode(String wbsCode) { this.wbsCode = wbsCode; }
    public String getMemberId() { return memberId; }
    public void setMemberId(String memberId) { this.memberId = memberId; }
}
