package com.manhour.model;

import jakarta.persistence.*;

@Entity
@Table(name = "app_user")
public class AppUser {
    @Id
    @Column(length = 40)
    private String memberId;
    @Column(nullable = false, length = 120)
    private String name;
    @Column(nullable = false)
    private String passwordHash;
    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 10)
    private Role role;
    @Column(nullable = false)
    private String securityQuestion;
    /** BCrypt of the trimmed, lower-cased answer. */
    @Column(nullable = false)
    private String securityAnswerHash;
    @Column(nullable = false)
    private int failedClueAttempts = 0;

    public String getMemberId() { return memberId; }
    public void setMemberId(String memberId) { this.memberId = memberId; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getPasswordHash() { return passwordHash; }
    public void setPasswordHash(String passwordHash) { this.passwordHash = passwordHash; }
    public Role getRole() { return role; }
    public void setRole(Role role) { this.role = role; }
    public String getSecurityQuestion() { return securityQuestion; }
    public void setSecurityQuestion(String q) { this.securityQuestion = q; }
    public String getSecurityAnswerHash() { return securityAnswerHash; }
    public void setSecurityAnswerHash(String h) { this.securityAnswerHash = h; }
    public int getFailedClueAttempts() { return failedClueAttempts; }
    public void setFailedClueAttempts(int n) { this.failedClueAttempts = n; }
}
