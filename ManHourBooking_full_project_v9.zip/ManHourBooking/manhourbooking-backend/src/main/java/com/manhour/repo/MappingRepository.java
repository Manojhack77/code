package com.manhour.repo;

import com.manhour.model.ProjectMapping;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MappingRepository extends JpaRepository<ProjectMapping, Long> {
    List<ProjectMapping> findByMemberId(String memberId);
    boolean existsByMemberIdAndWbsCode(String memberId, String wbsCode);
    long countByWbsCode(String wbsCode);
    void deleteByWbsCode(String wbsCode);
}
