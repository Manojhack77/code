package com.manhour.service;

import static com.manhour.dto.Dtos.*;
import static com.manhour.service.Money.r2;

import com.manhour.model.AppUser;
import com.manhour.model.Booking;
import com.manhour.model.MonthlyHours;
import com.manhour.model.PeriodEvent;
import com.manhour.model.PeriodLock;
import com.manhour.model.Project;
import com.manhour.model.Role;
import com.manhour.repo.BookingRepository;
import com.manhour.repo.MonthlyHoursRepository;
import com.manhour.repo.PeriodEventRepository;
import com.manhour.repo.PeriodLockRepository;
import com.manhour.repo.ProjectRepository;
import com.manhour.repo.UserRepository;
import com.manhour.security.AuthUser;
import com.manhour.web.ApiException;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.Month;
import java.time.YearMonth;
import java.time.format.TextStyle;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeSet;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * The manager's close of ONE month. Nothing is locked while a month is open (project expiry locks nothing).
 * A finalized month cannot change (hours, percentages, costs, rates) until an admin reopens it.
 * Every finalize and reopen is written to period_event, so nothing happens silently.
 */
@Service
public class PeriodService {
    private static final BigDecimal HUNDRED = BigDecimal.valueOf(100);
    private static final BigDecimal TOLERANCE = new BigDecimal("0.02"); // rounding leftovers are not "unassigned"
    private final PeriodLockRepository locks;
    private final PeriodEventRepository events;
    private final UserRepository users;
    private final MonthlyHoursRepository monthly;
    private final BookingRepository bookings;
    private final ProjectRepository projects;

    public PeriodService(PeriodLockRepository locks, PeriodEventRepository events, UserRepository users,
                         MonthlyHoursRepository monthly, BookingRepository bookings, ProjectRepository projects) {
        this.locks = locks;
        this.events = events;
        this.users = users;
        this.monthly = monthly;
        this.bookings = bookings;
        this.projects = projects;
    }

    public static String key(int month, int year) {
        return String.format("%04d-%02d", year, month);
    }

    private static String label(YearMonth ym) {
        return Month.of(ym.getMonthValue()).getDisplayName(TextStyle.FULL, Locale.ENGLISH) + " " + ym.getYear();
    }

    private static YearMonth month(Integer m, Integer y) {
        if (m == null || y == null || m < 1 || m > 12 || y < 2000 || y > 2100) throw ApiException.bad("Choose a valid month and year.");
        return YearMonth.of(y, m);
    }

    public boolean isFinal(int month, int year) {
        return locks.existsById(key(month, year));
    }

    /** Every write that changes hours, percentages or cost of a month calls this first. */
    public void requireOpen(int month, int year) {
        if (isFinal(month, year))
            throw ApiException.bad(label(YearMonth.of(year, month))
                    + " has been finalized by the manager. Hours and costs for this period can no longer be changed. "
                    + "An administrator can reopen it on the Member mapping page.");
    }

    private String who(AuthUser me) {
        return users.findById(me.memberId()).map(u -> u.getName() + " (" + u.getMemberId() + ")").orElse(me.memberId());
    }

    // ---------------- status ----------------
    @Transactional(readOnly = true)
    public PeriodStatus status(Integer month, Integer year) {
        YearMonth ym = month(month, year);
        String k = ym.toString();
        PeriodLock l = locks.findById(k).orElse(null);
        List<PeriodEvent> ev = new ArrayList<>(events.findByPeriodKey(k));
        ev.sort(Comparator.comparing(PeriodEvent::getId));
        PeriodEvent last = ev.isEmpty() ? null : ev.get(ev.size() - 1);
        if (l != null)
            return new PeriodStatus(k, true, "FINALIZED", l.getFinalizedBy(), l.getFinalizedAt(),
                    last != null && "FINALIZED".equals(last.getAction()) ? last.getReason() : null);
        if (last != null) return new PeriodStatus(k, false, last.getAction(), last.getDoneBy(), last.getDoneAt(), last.getReason());
        return new PeriodStatus(k, false, null, null, null, null);
    }

    // ---------------- readiness check ----------------
    /** What the manager should look at before finalizing. Warnings only: nothing here blocks finalizing. */
    @Transactional(readOnly = true)
    public PeriodCheck check(Integer month, Integer year) {
        YearMonth ym = month(month, year);
        int m = ym.getMonthValue();
        int y = ym.getYear();
        Map<String, BigDecimal> typed = new HashMap<>();
        for (MonthlyHours mh : monthly.findByMonthAndYear(m, y)) typed.put(mh.getMemberId(), r2(mh.getTotalHours()));
        Map<String, List<Booking>> rows = new HashMap<>();
        for (Booking b : bookings.search(m, y)) rows.computeIfAbsent(b.getMemberId(), k -> new ArrayList<>()).add(b);
        Map<String, Project> pById = new HashMap<>();
        for (Project p : projects.findAll()) pById.put(p.getWbsCode(), p);

        List<AppUser> staff = users.findByRoleOrderByMemberId(Role.STAFF);
        List<CheckIssue> issues = new ArrayList<>();
        int withHours = 0;
        int full = 0;
        BigDecimal unassignedTotal = BigDecimal.ZERO;
        for (AppUser u : staff) {
            String id = u.getMemberId();
            List<Booking> rs = rows.getOrDefault(id, List.of());
            if (!typed.containsKey(id) && rs.isEmpty()) {
                issues.add(new CheckIssue(id, u.getName(), "NO_HOURS", "No hours submitted for this month."));
                continue;
            }
            withHours++;
            BigDecimal pct = BigDecimal.ZERO;
            BigDecimal hrs = BigDecimal.ZERO;
            TreeSet<String> expired = new TreeSet<>();
            BigDecimal expiredPct = BigDecimal.ZERO;
            for (Booking b : rs) {
                pct = pct.add(b.getAllocationPercentage());
                hrs = hrs.add(b.getHoursBooked());
                Project p = pById.get(b.getWbsCode());
                if (p != null && p.isExpired()) {
                    expired.add(b.getWbsCode());
                    expiredPct = expiredPct.add(b.getAllocationPercentage());
                }
            }
            BigDecimal t = typed.containsKey(id) ? typed.get(id) : r2(hrs);
            BigDecimal remPct = r2(HUNDRED.subtract(pct));
            if (remPct.compareTo(TOLERANCE) > 0) {
                BigDecimal left = r2(t.subtract(hrs)).max(BigDecimal.ZERO);
                unassignedTotal = unassignedTotal.add(left);
                issues.add(new CheckIssue(id, u.getName(), "UNASSIGNED", plain(pct) + "% allocated, " + plain(remPct)
                        + "% (" + plain(left) + " h) not assigned to any project."));
            } else {
                full++;
            }
            if (!expired.isEmpty())
                issues.add(new CheckIssue(id, u.getName(), "EXPIRED", plain(expiredPct) + "% is on expired project "
                        + String.join(", ", expired) + "."));
        }
        return new PeriodCheck(m, y, isFinal(m, y), staff.size(), withHours, full, r2(unassignedTotal), issues);
    }

    private static String plain(BigDecimal v) {
        return r2(v).stripTrailingZeros().toPlainString();
    }

    // ---------------- finalize / reopen ----------------
    @Transactional
    public MessageResponse finalizeMonth(AuthUser me, PeriodRequest r) {
        YearMonth ym = month(r.month(), r.year());
        String k = ym.toString();
        if (locks.existsById(k)) throw ApiException.bad(label(ym) + " is already finalized.");
        LocalDateTime now = LocalDateTime.now();
        String by = who(me);
        locks.save(new PeriodLock(k, ym.atDay(1), ym.atEndOfMonth(), by, now));
        events.save(new PeriodEvent(k, "FINALIZED", by, now, clean(r.reason())));
        return new MessageResponse(label(ym) + " is finalized. Its hours and costs can no longer change unless you reopen it.");
    }

    @Transactional
    public MessageResponse reopen(AuthUser me, PeriodRequest r) {
        YearMonth ym = month(r.month(), r.year());
        String k = ym.toString();
        if (!locks.existsById(k)) throw ApiException.bad(label(ym) + " is not finalized.");
        locks.deleteById(k);
        events.save(new PeriodEvent(k, "REOPENED", who(me), LocalDateTime.now(), clean(r.reason())));
        return new MessageResponse(label(ym) + " is open again. Hours, allocations and rates for it can be edited. Finalize it again when you are done.");
    }

    private static String clean(String reason) {
        String s = reason == null ? "" : reason.trim();
        if (s.length() > 300) throw ApiException.bad("The reason can be at most 300 characters.");
        return s.isEmpty() ? null : s;
    }
}
