package com.manhour.repo;

import com.manhour.model.BaseRateChange;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BaseRateRepository extends JpaRepository<BaseRateChange, String> {
    List<BaseRateChange> findAllByOrderByEffectiveFromDesc();

    /** Latest change starting on or before the given "YYYY-MM". */
    Optional<BaseRateChange> findFirstByEffectiveFromLessThanEqualOrderByEffectiveFromDesc(String yearMonth);
}
