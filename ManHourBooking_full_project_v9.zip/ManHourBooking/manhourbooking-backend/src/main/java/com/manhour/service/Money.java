package com.manhour.service;

import java.math.BigDecimal;
import java.math.RoundingMode;

final class Money {
    private Money() {}

    static BigDecimal r2(BigDecimal v) {
        return v.setScale(2, RoundingMode.HALF_UP);
    }
}
