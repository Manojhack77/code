package com.manhour.repo;

import com.manhour.model.PeriodLock;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PeriodLockRepository extends JpaRepository<PeriodLock, String> {}
