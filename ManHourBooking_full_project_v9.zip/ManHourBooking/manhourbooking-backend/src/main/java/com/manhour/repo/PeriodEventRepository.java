package com.manhour.repo;

import com.manhour.model.PeriodEvent;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PeriodEventRepository extends JpaRepository<PeriodEvent, Long> {
    List<PeriodEvent> findByPeriodKey(String periodKey);
}
