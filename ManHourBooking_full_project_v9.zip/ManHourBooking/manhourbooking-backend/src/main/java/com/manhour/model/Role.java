package com.manhour.model;

public enum Role { STAFF, ADMIN }
