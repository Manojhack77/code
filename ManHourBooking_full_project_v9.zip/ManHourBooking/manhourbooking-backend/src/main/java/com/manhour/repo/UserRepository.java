package com.manhour.repo;

import com.manhour.model.AppUser;
import com.manhour.model.Role;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<AppUser, String> {
    Optional<AppUser> findByMemberIdIgnoreCase(String memberId);
    List<AppUser> findByRoleOrderByMemberId(Role role);
    boolean existsByMemberIdIgnoreCase(String memberId);
}
