package com.manhour.model;

import jakarta.persistence.*;
import java.math.BigDecimal;

/**
 * One row of the base-rate history. ONE hourly rate applies to all staff; a row says "from this month on,
 * the rate is X". effectiveFrom is "YYYY-MM" (sorts correctly as text). The first row is "2000-01".
 */
@Entity
@Table(name = "base_rate_change")
public class BaseRateChange {
    public static final String BASE_FROM = "2000-01";

    @Id
    @Column(length = 7)
    private String effectiveFrom;
    @Column(nullable = false, precision = 12, scale = 2)
    private BigDecimal rate;

    public BaseRateChange() {}
    public BaseRateChange(String effectiveFrom, BigDecimal rate) { this.effectiveFrom = effectiveFrom; this.rate = rate; }

    public String getEffectiveFrom() { return effectiveFrom; }
    public BigDecimal getRate() { return rate; }
    public void setRate(BigDecimal rate) { this.rate = rate; }
}
