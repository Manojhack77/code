package com.manhour.service;

import static com.manhour.service.Money.r2;

import com.manhour.model.Project;
import com.manhour.repo.ProjectRepository;
import com.manhour.web.ApiException;
import java.math.BigDecimal;
import java.util.Map;
import java.util.TreeMap;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * Keeps the budget invariant: Available = Allotted - Booked.
 * Every change is validated first and applied after, inside the caller's transaction (all or nothing).
 */
@Service
public class BudgetService {
    private final ProjectRepository projects;

    public BudgetService(ProjectRepository projects) {
        this.projects = projects;
    }

    /**
     * @param deltas  wbsCode -> cost change (positive = more spent, negative = refund)
     * @param detailed admins see amounts in error messages; staff must never see budget figures
     */
    @Transactional(propagation = Propagation.MANDATORY)
    public void apply(Map<String, BigDecimal> deltas, boolean detailed) {
        // Sorted order + row locks: two requests touching the same projects cannot deadlock or overspend.
        Map<String, BigDecimal> sorted = new TreeMap<>(deltas);
        Map<String, Project> locked = new TreeMap<>();
        for (String wbs : sorted.keySet()) {
            locked.put(wbs, projects.lockByCode(wbs)
                    .orElseThrow(() -> ApiException.bad("Project " + wbs + " does not exist.")));
        }
        for (var e : sorted.entrySet()) {
            Project p = locked.get(e.getKey());
            BigDecimal delta = r2(e.getValue());
            if (delta.compareTo(p.getAmountAvailable()) > 0) {
                throw ApiException.bad(detailed
                        ? "Not enough budget in " + p.getWbsCode() + ": needs " + delta + " but only "
                                + p.getAmountAvailable() + " is available."
                        : "Not enough budget left in " + p.getWbsCode() + ". Ask your administrator.");
            }
        }
        for (var e : sorted.entrySet()) {
            Project p = locked.get(e.getKey());
            p.setAmountBooked(r2(p.getAmountBooked().add(e.getValue())));
            p.setAmountAvailable(r2(p.getAmountAllotted().subtract(p.getAmountBooked())));
            projects.save(p);
        }
    }
}
