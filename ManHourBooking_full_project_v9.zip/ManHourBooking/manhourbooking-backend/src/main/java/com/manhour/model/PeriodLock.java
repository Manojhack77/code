package com.manhour.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * A finalized month. Hours are booked per month, so a date range chosen by the manager locks every month it
 * touches, one row per month. The range that was asked for is kept on each row as a record.
 */
@Entity
@Table(name = "period_lock")
public class PeriodLock {
    @Id
    @Column(length = 7)
    private String periodKey; // "YYYY-MM"
    @Column(nullable = false)
    private LocalDate rangeFrom;
    @Column(nullable = false)
    private LocalDate rangeTo;
    @Column(nullable = false, length = 160)
    private String finalizedBy;
    @Column(nullable = false)
    private LocalDateTime finalizedAt;

    public PeriodLock() {}

    public PeriodLock(String periodKey, LocalDate rangeFrom, LocalDate rangeTo, String finalizedBy, LocalDateTime finalizedAt) {
        this.periodKey = periodKey;
        this.rangeFrom = rangeFrom;
        this.rangeTo = rangeTo;
        this.finalizedBy = finalizedBy;
        this.finalizedAt = finalizedAt;
    }

    public String getPeriodKey() { return periodKey; }
    public LocalDate getRangeFrom() { return rangeFrom; }
    public LocalDate getRangeTo() { return rangeTo; }
    public String getFinalizedBy() { return finalizedBy; }
    public LocalDateTime getFinalizedAt() { return finalizedAt; }
}
