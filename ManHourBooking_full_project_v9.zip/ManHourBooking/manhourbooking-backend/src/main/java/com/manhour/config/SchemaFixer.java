package com.manhour.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

/**
 * Allocation percentages are now decimals (a typed hours value such as 37 of 160 is 23.13%). Hibernate's
 * "update" mode never changes the type of an existing column, so on a database created by the older version
 * this widens the two INT columns once. On a fresh database it does nothing.
 */
@Component
@Order(1)
public class SchemaFixer implements CommandLineRunner {
    private static final Logger log = LoggerFactory.getLogger(SchemaFixer.class);
    private final JdbcTemplate jdbc;

    public SchemaFixer(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    @Override
    public void run(String... args) {
        for (String table : new String[] {"booking", "project_member_mapping"}) {
            try {
                String type = jdbc.queryForObject(
                        "select data_type from information_schema.columns where table_schema = database() "
                                + "and table_name = ? and column_name = 'allocation_percentage'", String.class, table);
                if (type != null && !type.equalsIgnoreCase("decimal")) {
                    jdbc.execute("ALTER TABLE " + table + " MODIFY allocation_percentage DECIMAL(5,2) NOT NULL");
                    log.info("Converted {}.allocation_percentage from {} to DECIMAL(5,2).", table, type);
                }
            } catch (EmptyResultDataAccessException e) {
                // column not there yet: nothing to convert
            } catch (Exception e) {
                log.warn("Could not check {}.allocation_percentage: {}. Run the ALTER TABLE in the README by hand.", table, e.getMessage());
            }
        }
        migrateOldClosures();
        migrateProjectMembers();
    }

    /**
     * An earlier version stored finalized months in period_closure. Carry them over to period_lock so
     * months you already finalized stay locked. The old tables are left alone (drop them by hand if unwanted).
     */
    private void migrateOldClosures() {
        try {
            Integer n = jdbc.queryForObject("select count(*) from information_schema.tables where table_schema = database() "
                    + "and table_name = 'period_closure'", Integer.class);
            if (n != null && n > 0) {
                int c = jdbc.update("insert ignore into period_lock (period_key, range_from, range_to, finalized_by, finalized_at) "
                        + "select period_key, str_to_date(concat(period_key, '-01'), '%Y-%m-%d'), "
                        + "last_day(str_to_date(concat(period_key, '-01'), '%Y-%m-%d')), finalized_by, finalized_at from period_closure");
                if (c > 0) log.info("Carried {} finalized month(s) over from period_closure to period_lock.", c);
            }
        } catch (Exception e) {
            log.warn("Could not carry old finalized months over: {}", e.getMessage());
        }
    }

    /**
     * Project membership was introduced after allocations. Everyone who already has a standing allocation or
     * a booking on a project is made a member of it, so existing assignments keep working. Safe to run on every
     * start (insert ignore + unique key); a member cannot be removed while such rows exist anyway.
     */
    private void migrateProjectMembers() {
        try {
            int a = jdbc.update("insert ignore into project_member (wbs_code, member_id) "
                    + "select distinct wbs_code, member_id from project_member_mapping");
            int b = jdbc.update("insert ignore into project_member (wbs_code, member_id) "
                    + "select distinct wbs_code, member_id from booking");
            if (a + b > 0) log.info("Added {} existing assignment(s) as project members.", a + b);
        } catch (Exception e) {
            log.warn("Could not fill project_member from existing assignments: {}", e.getMessage());
        }
    }
}
