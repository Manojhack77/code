package com.manhour.service;

import static com.manhour.dto.Dtos.*;

import com.manhour.model.AppUser;
import com.manhour.model.Role;
import com.manhour.repo.UserRepository;
import com.manhour.security.JwtService;
import com.manhour.web.ApiException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class AuthService {
    private final UserRepository users;
    private final PasswordEncoder encoder;
    private final JwtService jwt;
    private final int maxClueTries;

    public AuthService(UserRepository users, PasswordEncoder encoder, JwtService jwt,
                       @Value("${app.clue.max-tries}") int maxClueTries) {
        this.users = users;
        this.encoder = encoder;
        this.jwt = jwt;
        this.maxClueTries = maxClueTries;
    }

    /** Clue answers are compared trimmed and lower-cased, so "Greenfield " matches "greenfield". */
    static String norm(String s) {
        return s == null ? "" : s.trim().toLowerCase();
    }

    private AuthResponse tokenFor(AppUser u) {
        return new AuthResponse(jwt.generate(u.getMemberId(), u.getRole()),
                new UserInfo(u.getMemberId(), u.getName(), u.getRole().name()));
    }

    @Transactional(readOnly = true)
    public AuthResponse login(LoginRequest r) {
        AppUser u = r.userId() == null ? null : users.findByMemberIdIgnoreCase(r.userId().trim()).orElse(null);
        if (u == null || r.password() == null || !encoder.matches(r.password(), u.getPasswordHash()))
            throw new ApiException(HttpStatus.UNAUTHORIZED, "Invalid user ID or password.");
        return tokenFor(u);
    }

    /** Sign-up always creates a STAFF account with the shared base rate. */
    @Transactional
    public AuthResponse signup(SignupRequest r) {
        String id = r.memberId() == null ? "" : r.memberId().trim();
        String name = r.name() == null ? "" : r.name().trim();
        if (id.isEmpty() || name.isEmpty() || r.password() == null || r.password().isEmpty())
            throw ApiException.bad("All fields are required.");
        if (id.length() > 40) throw ApiException.bad("Staff ID is too long.");
        if (r.password().length() < 6) throw ApiException.bad("Password must be at least 6 characters.");
        if (r.securityQuestion() == null || r.securityQuestion().isBlank() || norm(r.securityAnswer()).length() < 2)
            throw ApiException.bad("Choose a clue question and give an answer.");
        if (users.existsByMemberIdIgnoreCase(id)) throw ApiException.conflict("That staff ID is already registered.");

        AppUser u = new AppUser();
        u.setMemberId(id);
        u.setName(name);
        u.setRole(Role.STAFF);
        u.setPasswordHash(encoder.encode(r.password()));
        u.setSecurityQuestion(r.securityQuestion().trim());
        u.setSecurityAnswerHash(encoder.encode(norm(r.securityAnswer())));
        users.save(u);
        return tokenFor(u);
    }

    @Transactional(readOnly = true)
    public ForgotQuestionResponse forgotQuestion(ForgotQuestionRequest r) {
        AppUser u = find(r.userId());
        return new ForgotQuestionResponse(u.getSecurityQuestion());
    }

    /**
     * noRollbackFor: a wrong answer throws, but the failed-attempt counter must still be saved,
     * otherwise the 5-try lock could never trigger.
     */
    @Transactional(noRollbackFor = ApiException.class)
    public MessageResponse forgotReset(ForgotResetRequest r) {
        AppUser u = find(r.userId());
        if (u.getFailedClueAttempts() >= maxClueTries)
            throw ApiException.bad("Too many wrong answers. Ask your administrator to reset your password.");
        if (r.newPassword() == null || r.newPassword().length() < 6)
            throw ApiException.bad("Password must be at least 6 characters.");
        if (!encoder.matches(norm(r.answer()), u.getSecurityAnswerHash())) {
            u.setFailedClueAttempts(u.getFailedClueAttempts() + 1);
            users.save(u);
            throw ApiException.bad("That answer does not match.");
        }
        u.setPasswordHash(encoder.encode(r.newPassword()));
        u.setFailedClueAttempts(0);
        users.save(u);
        return new MessageResponse("Password changed. You can log in now.");
    }

    private AppUser find(String userId) {
        if (userId == null || userId.isBlank()) throw ApiException.notFound("No account found with that ID.");
        return users.findByMemberIdIgnoreCase(userId.trim())
                .orElseThrow(() -> ApiException.notFound("No account found with that ID."));
    }
}
