package com.manhour.config;

import com.manhour.model.AppUser;
import com.manhour.model.BaseRateChange;
import com.manhour.model.Role;
import com.manhour.repo.BaseRateRepository;
import com.manhour.repo.UserRepository;
import java.math.BigDecimal;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

/** First-run data: the starting base rate (placeholder, edit it in the Rates tab) and one admin. */
@Component
public class DataSeeder implements CommandLineRunner {
    private static final Logger log = LoggerFactory.getLogger(DataSeeder.class);
    private final BaseRateRepository rates;
    private final UserRepository users;
    private final PasswordEncoder encoder;

    public DataSeeder(BaseRateRepository rates, UserRepository users, PasswordEncoder encoder) {
        this.rates = rates;
        this.users = users;
        this.encoder = encoder;
    }

    @Override
    public void run(String... args) {
        if (rates.count() == 0) {
            // Placeholder starting rate: change it on the admin Rates tab.
            rates.save(new BaseRateChange(BaseRateChange.BASE_FROM, BigDecimal.valueOf(500).setScale(2)));
        }
        if (users.findByRoleOrderByMemberId(Role.ADMIN).isEmpty()) {
            AppUser admin = new AppUser();
            admin.setMemberId("ADMIN01");
            admin.setName("Admin User");
            admin.setRole(Role.ADMIN);
            admin.setPasswordHash(encoder.encode("admin123"));
            admin.setSecurityQuestion("What was the name of your first school?");
            admin.setSecurityAnswerHash(encoder.encode("greenfield"));
            users.save(admin);
            log.warn("Seeded default admin ADMIN01 / admin123 (clue answer: greenfield). Change these before going live.");
        }
    }
}
