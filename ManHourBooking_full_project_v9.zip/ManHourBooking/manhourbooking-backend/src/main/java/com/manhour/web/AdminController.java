package com.manhour.web;

import static com.manhour.dto.Dtos.*;

import com.manhour.security.AuthUser;
import com.manhour.service.AdminService;
import com.manhour.service.AllocationService;
import com.manhour.service.PeriodService;
import java.util.List;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/admin")
public class AdminController {
    private final AdminService admin;
    private final AllocationService allocations;
    private final PeriodService periods;

    public AdminController(AdminService admin, AllocationService allocations, PeriodService periods) {
        this.admin = admin;
        this.allocations = allocations;
        this.periods = periods;
    }

    // ---- dashboard (read-only) ----
    @GetMapping("/bookings")
    public List<BookingView> bookings(@RequestParam(required = false) Integer month,
                                      @RequestParam(required = false) Integer year) {
        return admin.bookings(month, year);
    }

    // ---- projects ----
    @GetMapping("/projects")
    public List<ProjectView> projects() { return admin.projects(); }
    @PostMapping("/projects")
    public ProjectView createProject(@RequestBody ProjectCreateRequest r) { return admin.createProject(r); }
    @PutMapping("/projects/{wbsCode}")
    public ProjectView updateProject(@PathVariable String wbsCode, @RequestBody ProjectUpdateRequest r) {
        return admin.updateProject(wbsCode, r);
    }
    @PutMapping("/projects/{wbsCode}/members")
    public ProjectView setProjectMembers(@PathVariable String wbsCode, @RequestBody MembersRequest r) {
        return admin.setMembers(wbsCode, r);
    }
    @DeleteMapping("/projects/{wbsCode}")
    public MessageResponse deleteProject(@PathVariable String wbsCode) { return admin.deleteProject(wbsCode); }

    // ---- staff, base rate ----
    @GetMapping("/staff")
    public List<StaffView> staff() { return admin.staff(); }
    @PutMapping("/staff/{memberId}/password")
    public MessageResponse resetPassword(@PathVariable String memberId, @RequestBody PasswordRequest r) {
        return admin.resetPassword(memberId, r.password());
    }
    @GetMapping("/base-rate")
    public BaseRateView baseRate() { return admin.baseRate(); }
    @PostMapping("/base-rate/preview")
    public RatePreview previewRate(@RequestBody RateChangeRequest r) { return admin.previewRateChange(r); }
    @PostMapping("/base-rate/changes")
    public MessageResponse saveRateChange(@RequestBody RateChangeRequest r) { return admin.saveRateChange(r); }
    @DeleteMapping("/base-rate/changes/{effectiveFrom}")
    public MessageResponse deleteRateChange(@PathVariable String effectiveFrom) { return admin.deleteRateChange(effectiveFrom); }

    // ---- member mapping (allocation, total hours) ----
    @GetMapping("/allocations")
    public List<AllocationSummary> allocations(@RequestParam(required = false) Integer month,
                                               @RequestParam(required = false) Integer year) {
        return allocations.list(month, year);
    }
    @GetMapping("/allocations/{memberId}")
    public AllocationDetail allocation(@PathVariable String memberId,
                                       @RequestParam(required = false) Integer month,
                                       @RequestParam(required = false) Integer year) {
        return allocations.detail(memberId, month, year);
    }
    @PutMapping("/allocations/{memberId}")
    public MessageResponse saveAllocation(@PathVariable String memberId, @RequestBody AllocationSaveRequest r) {
        return allocations.save(memberId, r);
    }
    @PutMapping("/allocations/{memberId}/hours")
    public MessageResponse setHours(@PathVariable String memberId, @RequestBody HoursRequest r) {
        if (r.month() == null || r.year() == null) throw ApiException.bad("Choose a valid month and year.");
        return allocations.setMonthHours(memberId, r.month(), r.year(), r.hours(), true);
    }
    @PostMapping("/allocations/{memberId}/assign")
    public MessageResponse assign(@PathVariable String memberId, @RequestBody AssignRequest r) {
        return allocations.assign(memberId, r);
    }

    // ---- one-month close (finalize / reopen) ----
    @GetMapping("/periods/status")
    public PeriodStatus periodStatus(@RequestParam Integer month, @RequestParam Integer year) {
        return periods.status(month, year);
    }
    @GetMapping("/periods/check")
    public PeriodCheck periodCheck(@RequestParam Integer month, @RequestParam Integer year) {
        return periods.check(month, year);
    }
    @PostMapping("/periods/finalize")
    public MessageResponse finalizePeriod(@AuthenticationPrincipal AuthUser me, @RequestBody PeriodRequest r) {
        return periods.finalizeMonth(me, r);
    }
    @PostMapping("/periods/reopen")
    public MessageResponse reopenPeriod(@AuthenticationPrincipal AuthUser me, @RequestBody PeriodRequest r) {
        return periods.reopen(me, r);
    }
}
