package com.manhour.security;

import com.manhour.model.Role;

/** Principal placed in the SecurityContext for every authenticated request. */
public record AuthUser(String memberId, Role role) {}
