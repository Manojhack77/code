package com.manhour.repo;

import com.manhour.model.Project;
import jakarta.persistence.LockModeType;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface ProjectRepository extends JpaRepository<Project, String> {
    /** Row lock so concurrent bookings cannot overspend a budget. */
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select p from Project p where p.wbsCode = :code")
    Optional<Project> lockByCode(@Param("code") String code);
}
