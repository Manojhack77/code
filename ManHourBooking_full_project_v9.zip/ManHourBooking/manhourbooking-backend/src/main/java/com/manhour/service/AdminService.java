package com.manhour.service;

import static com.manhour.dto.Dtos.*;
import static com.manhour.service.Money.r2;

import com.manhour.model.AppUser;
import com.manhour.model.Booking;
import com.manhour.model.Project;
import com.manhour.model.ProjectMapping;
import com.manhour.model.ProjectMember;
import com.manhour.model.BaseRateChange;
import com.manhour.model.MonthlyHours;
import com.manhour.model.Role;
import com.manhour.repo.BookingRepository;
import com.manhour.repo.BaseRateRepository;
import com.manhour.repo.MappingRepository;
import com.manhour.repo.ProjectMemberRepository;
import com.manhour.repo.ProjectRepository;
import com.manhour.repo.UserRepository;
import com.manhour.web.ApiException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.stream.Collectors;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class AdminService {
    private final UserRepository users;
    private final ProjectRepository projects;
    private final MappingRepository mappings;
    private final ProjectMemberRepository members;
    private final BookingRepository bookings;
    private final BaseRateRepository rates;
    private final PasswordEncoder encoder;
    private final PeriodService periods;
    private final BudgetService budget;

    public AdminService(UserRepository users, ProjectRepository projects, MappingRepository mappings,
                        ProjectMemberRepository members, BookingRepository bookings, BaseRateRepository rates, PasswordEncoder encoder,
                        PeriodService periods, BudgetService budget) {
        this.users = users;
        this.projects = projects;
        this.mappings = mappings;
        this.members = members;
        this.bookings = bookings;
        this.rates = rates;
        this.encoder = encoder;
        this.periods = periods;
        this.budget = budget;
    }

    // ---------------- dashboard ----------------
    @Transactional(readOnly = true)
    public List<BookingView> bookings(Integer month, Integer year) {
        Map<String, Project> pById = projects.findAll().stream().collect(Collectors.toMap(Project::getWbsCode, p -> p));
        Map<String, String> names = users.findAll().stream().collect(Collectors.toMap(AppUser::getMemberId, AppUser::getName));
        return bookings.search(month, year).stream().map(b -> {
            Project p = pById.get(b.getWbsCode());
            return new BookingView(b.getBookingId(), b.getWbsCode(), p == null ? "" : p.getProjectName(),
                    b.getMemberId(), names.getOrDefault(b.getMemberId(), b.getMemberId()),
                    b.getHoursBooked(), b.getCalculatedCost(), b.getMonth(), b.getYear(),
                    p != null && p.isExpired());
        }).toList();
    }

    // ---------------- projects ----------------
    private static ProjectView view(Project p, List<MemberRef> memberList) {
        return new ProjectView(p.getWbsCode(), p.getProjectName(), p.getExpiryDate(), p.getAmountAllotted(),
                p.getAmountAvailable(), p.getAmountBooked(), p.isExpired() ? "Expired" : "Active", memberList);
    }

    /** The members of one project as id + name, ordered by id. */
    private List<MemberRef> memberRefs(String wbsCode) {
        Map<String, String> names = users.findAll().stream().collect(Collectors.toMap(AppUser::getMemberId, AppUser::getName));
        return members.findByWbsCode(wbsCode).stream().map(ProjectMember::getMemberId).sorted()
                .map(id -> new MemberRef(id, names.getOrDefault(id, id))).toList();
    }

    @Transactional(readOnly = true)
    public List<ProjectView> projects() {
        Map<String, String> names = users.findAll().stream().collect(Collectors.toMap(AppUser::getMemberId, AppUser::getName));
        Map<String, List<MemberRef>> byProject = new HashMap<>();
        for (ProjectMember pm : members.findAll())
            byProject.computeIfAbsent(pm.getWbsCode(), k -> new ArrayList<>())
                    .add(new MemberRef(pm.getMemberId(), names.getOrDefault(pm.getMemberId(), pm.getMemberId())));
        byProject.values().forEach(l -> l.sort((a, b) -> a.memberId().compareTo(b.memberId())));
        return projects.findAll().stream().sorted((a, b) -> a.getWbsCode().compareTo(b.getWbsCode()))
                .map(p -> view(p, byProject.getOrDefault(p.getWbsCode(), List.of()))).toList();
    }

    @Transactional
    public ProjectView createProject(ProjectCreateRequest r) {
        String code = r.wbsCode() == null ? "" : r.wbsCode().trim().toUpperCase();
        if (code.isEmpty() || r.projectName() == null || r.projectName().isBlank() || r.expiryDate() == null)
            throw ApiException.bad("WBS code, name and expiry date are required.");
        if (r.amountAllotted() == null || r2(r.amountAllotted()).signum() <= 0)
            throw ApiException.bad("Amount allotted must be greater than zero.");
        if (projects.existsById(code)) throw ApiException.conflict("A project with this WBS code already exists.");
        Project p = new Project();
        p.setWbsCode(code);
        p.setProjectName(r.projectName().trim());
        p.setExpiryDate(r.expiryDate());
        p.setAmountAllotted(r2(r.amountAllotted()));
        p.setAmountBooked(BigDecimal.ZERO.setScale(2));
        p.setAmountAvailable(p.getAmountAllotted());
        return view(projects.save(p), List.of());
    }

    @Transactional
    public ProjectView updateProject(String wbsCode, ProjectUpdateRequest r) {
        Project p = projects.lockByCode(wbsCode).orElseThrow(() -> ApiException.notFound("Project not found."));
        if (r.projectName() == null || r.projectName().isBlank() || r.expiryDate() == null)
            throw ApiException.bad("Project name and expiry date are required.");
        if (r.amountAllotted() == null) throw ApiException.bad("Amount allotted is required.");
        BigDecimal amt = r2(r.amountAllotted());
        if (amt.compareTo(p.getAmountBooked()) < 0)
            throw ApiException.bad("Amount allotted cannot be below the amount already booked (" + p.getAmountBooked() + ").");
        p.setProjectName(r.projectName().trim());
        p.setExpiryDate(r.expiryDate());
        p.setAmountAllotted(amt);
        p.setAmountAvailable(r2(amt.subtract(p.getAmountBooked()))); // invariant: available = allotted - booked
        return view(projects.save(p), memberRefs(wbsCode));
    }

    /**
     * Replaces the member list of a project with the given staff IDs. A member who still has a standing
     * allocation on the project, or hours in a month that is not finalized, cannot be removed: take the
     * allocation off on Member mapping first.
     */
    @Transactional
    public ProjectView setMembers(String wbsCode, MembersRequest r) {
        Project p = projects.lockByCode(wbsCode).orElseThrow(() -> ApiException.notFound("Project not found."));
        if (r == null || r.memberIds() == null) throw ApiException.bad("Choose the members.");
        Set<String> want = new LinkedHashSet<>();
        for (String raw : r.memberIds()) {
            String id = raw == null ? "" : raw.trim();
            if (!id.isEmpty()) want.add(id);
        }
        Map<String, AppUser> staff = users.findByRoleOrderByMemberId(Role.STAFF).stream()
                .collect(Collectors.toMap(AppUser::getMemberId, u -> u));
        for (String id : want)
            if (!staff.containsKey(id)) throw ApiException.notFound("Staff member " + id + " not found.");
        List<ProjectMember> current = members.findByWbsCode(wbsCode);
        Set<String> have = new LinkedHashSet<>();
        for (ProjectMember pm : current) have.add(pm.getMemberId());
        List<Booking> projectBookings = bookings.findByWbsCode(wbsCode);
        List<ProjectMember> toRemove = new ArrayList<>();
        for (ProjectMember pm : current) {
            if (want.contains(pm.getMemberId())) continue;
            String id = pm.getMemberId();
            boolean allocated = mappings.existsByMemberIdAndWbsCode(id, wbsCode);
            boolean openHours = projectBookings.stream()
                    .anyMatch(b -> b.getMemberId().equals(id) && !periods.isFinal(b.getMonth(), b.getYear()));
            if (allocated || openHours) {
                AppUser u = staff.get(id);
                throw ApiException.bad((u == null ? id : u.getName()) + " still has an allocation on " + wbsCode
                        + ". Remove it on the Member mapping page first, then remove the member.");
            }
            toRemove.add(pm);
        }
        members.deleteAll(toRemove);
        List<ProjectMember> toAdd = new ArrayList<>();
        for (String id : want) if (!have.contains(id)) toAdd.add(new ProjectMember(wbsCode, id));
        members.saveAll(toAdd);
        return view(p, memberRefs(wbsCode));
    }

    /**
     * Deletes a project together with everything that belongs to it: all its bookings and all staff
     * assignments. Staff members' typed monthly totals are kept; the part that was on this project
     * simply becomes unassigned. This cannot be undone.
     */
    @Transactional
    public MessageResponse deleteProject(String wbsCode) {
        if (!projects.existsById(wbsCode)) throw ApiException.notFound("Project not found.");
        if (bookings.findByWbsCode(wbsCode).stream().anyMatch(b -> periods.isFinal(b.getMonth(), b.getYear())))
            throw ApiException.bad("This project has bookings in a finalized period, so it cannot be deleted.");
        long bookingCount = bookings.countByWbsCode(wbsCode);
        long mappingCount = mappings.countByWbsCode(wbsCode);
        bookings.deleteByWbsCode(wbsCode);
        mappings.deleteByWbsCode(wbsCode);
        members.deleteByWbsCode(wbsCode);
        projects.deleteById(wbsCode);
        return new MessageResponse("Project " + wbsCode + " deleted with " + bookingCount + " booking(s) and "
                + mappingCount + " assignment(s).");
    }

    // ---------------- staff, base rate ----------------
    @Transactional(readOnly = true)
    public List<StaffView> staff() {
        Map<String, BigDecimal> totals = new HashMap<>();
        for (ProjectMapping m : mappings.findAll()) totals.merge(m.getMemberId(), m.getAllocationPercentage(), BigDecimal::add);
        return users.findByRoleOrderByMemberId(Role.STAFF).stream()
                .map(u -> new StaffView(u.getMemberId(), u.getName(), totals.getOrDefault(u.getMemberId(), BigDecimal.ZERO))).toList();
    }

    /** Admin reset for staff who forgot the clue answer too. Also clears the clue lock. */
    @Transactional
    public MessageResponse resetPassword(String memberId, String password) {
        AppUser u = staffUser(memberId);
        if (password == null || password.length() < 6) throw ApiException.bad("Password must be at least 6 characters.");
        u.setPasswordHash(encoder.encode(password));
        u.setFailedClueAttempts(0);
        users.save(u);
        return new MessageResponse("Password reset.");
    }

    // ---------------- base rate ----------------
    private static String currentMonth() {
        return YearMonth.now().toString(); // "YYYY-MM"
    }

    /** The rate in force this month plus the full history, newest first. */
    @Transactional(readOnly = true)
    public BaseRateView baseRate() {
        BigDecimal inForce = rates.findFirstByEffectiveFromLessThanEqualOrderByEffectiveFromDesc(currentMonth())
                .map(BaseRateChange::getRate)
                .orElseGet(() -> rates.findAllByOrderByEffectiveFromDesc().stream().reduce((a, b) -> b)
                        .map(BaseRateChange::getRate).orElse(BigDecimal.ZERO));
        List<RateRow> history = rates.findAllByOrderByEffectiveFromDesc().stream()
                .map(h -> new RateRow(h.getEffectiveFrom(), h.getRate())).toList();
        return new BaseRateView(inForce, history);
    }

    // A rate row as plain values, so a change can be tried out before anything is written.
    private record RateLine(String from, BigDecimal rate) {}

    private List<RateLine> rateLines() {
        List<RateLine> out = new ArrayList<>();
        for (BaseRateChange c : rates.findAll()) out.add(new RateLine(c.getEffectiveFrom(), c.getRate()));
        return out;
    }

    private static BigDecimal rateIn(List<RateLine> lines, String ym) {
        RateLine best = null;
        for (RateLine l : lines) if (l.from().compareTo(ym) <= 0 && (best == null || l.from().compareTo(best.from()) > 0)) best = l;
        return best == null ? null : best.rate();
    }

    /** The list as it would be after setting (rate given) or removing (rate null) the row starting at "from". */
    private static List<RateLine> modified(List<RateLine> before, String from, BigDecimal rate) {
        List<RateLine> out = new ArrayList<>();
        for (RateLine l : before) if (!l.from().equals(from)) out.add(l);
        if (rate != null) out.add(new RateLine(from, rate));
        return out;
    }

    private String checkedFrom(String raw) {
        String from = raw == null ? "" : raw.trim();
        if (!from.equals(BaseRateChange.BASE_FROM) && !from.matches("\\d{4}-(0[1-9]|1[0-2])"))
            throw ApiException.bad("Choose the month the rate starts.");
        if (!from.equals(BaseRateChange.BASE_FROM) && periods.isFinal(Integer.parseInt(from.substring(5)), Integer.parseInt(from.substring(0, 4))))
            throw ApiException.bad("That month is finalized. Reopen it on the Member mapping page first, or start the rate from an open month.");
        return from;
    }

    /**
     * Reprices every booking whose month's rate would change (before -> after), unless that month is finalized
     * (finalized months are reported, never touched). Hours stay the same; cost = hours x the new rate; project
     * budgets move by the difference. With apply = false nothing is written (preview).
     */
    private RatePreview reprice(List<RateLine> before, List<RateLine> after, boolean apply) {
        Map<String, List<Booking>> byMonth = new TreeMap<>();
        for (Booking b : bookings.findAll()) byMonth.computeIfAbsent(PeriodService.key(b.getMonth(), b.getYear()), k -> new ArrayList<>()).add(b);
        List<String> months = new ArrayList<>();
        List<String> locked = new ArrayList<>();
        Map<String, BigDecimal> deltas = new LinkedHashMap<>();
        List<Booking> changed = new ArrayList<>();
        List<BigDecimal[]> newValues = new ArrayList<>(); // {rate, cost} per changed booking, applied only after all checks
        BigDecimal diff = BigDecimal.ZERO;
        int count = 0;
        for (var e : byMonth.entrySet()) {
            String ym = e.getKey();
            BigDecimal oldRate = rateIn(before, ym);
            BigDecimal newRate = rateIn(after, ym);
            if (oldRate == null || newRate == null || oldRate.compareTo(newRate) == 0) continue;
            if (periods.isFinal(Integer.parseInt(ym.substring(5)), Integer.parseInt(ym.substring(0, 4)))) {
                locked.add(ym);
                continue;
            }
            months.add(ym);
            for (Booking b : e.getValue()) {
                BigDecimal cost = r2(b.getHoursBooked().multiply(newRate));
                BigDecimal delta = cost.subtract(b.getCalculatedCost());
                deltas.merge(b.getWbsCode(), delta, BigDecimal::add);
                diff = diff.add(delta);
                count++;
                if (apply) {
                    changed.add(b);
                    newValues.add(new BigDecimal[] {newRate, cost});
                }
            }
        }
        List<String> problems = new ArrayList<>();
        for (var d : deltas.entrySet()) {
            Project p = projects.findById(d.getKey()).orElse(null);
            if (p != null && d.getValue().compareTo(p.getAmountAvailable()) > 0)
                problems.add(d.getKey() + " needs " + d.getValue().subtract(p.getAmountAvailable()).setScale(2, RoundingMode.HALF_UP)
                        + " more budget (only " + p.getAmountAvailable() + " is available).");
        }
        if (apply) {
            if (!problems.isEmpty()) throw ApiException.bad("The rate was not changed. " + String.join(" ", problems));
            budget.apply(deltas, true);
            for (int i = 0; i < changed.size(); i++) {
                changed.get(i).setRateApplied(newValues.get(i)[0]);
                changed.get(i).setCalculatedCost(newValues.get(i)[1]);
            }
            bookings.saveAll(changed);
        }
        return new RatePreview(count, months, locked, r2(diff), problems);
    }

    /** What would be recalculated if this rate were saved (rate given) or this row removed (rate empty). */
    @Transactional(readOnly = true)
    public RatePreview previewRateChange(RateChangeRequest r) {
        String from = checkedFrom(r.effectiveFrom());
        BigDecimal rate = null;
        List<RateLine> before = rateLines();
        if (r.rate() != null) {
            rate = r2(r.rate());
            if (rate.signum() <= 0) throw ApiException.bad("Rate must be greater than zero.");
        } else if (from.equals(BaseRateChange.BASE_FROM)) {
            throw ApiException.bad("The base rate cannot be removed. Edit it instead.");
        }
        return reprice(before, modified(before, from, rate), false);
    }

    /**
     * Set the base rate from a month onward (applies to ALL staff). Bookings of open months that fall under
     * the changed rate are recalculated; finalized months never change. A rate row can only be added, edited
     * or removed when its start month is open (the starting row "2000-01" can always be edited).
     */
    @Transactional
    public MessageResponse saveRateChange(RateChangeRequest r) {
        String from = checkedFrom(r.effectiveFrom());
        if (r.rate() == null || r2(r.rate()).signum() <= 0) throw ApiException.bad("Rate must be greater than zero.");
        BigDecimal rate = r2(r.rate());
        List<RateLine> before = rateLines();
        RatePreview p = reprice(before, modified(before, from, rate), true);
        BaseRateChange row = rates.findById(from).orElse(null);
        if (row == null) rates.save(new BaseRateChange(from, rate));
        else {
            row.setRate(rate);
            rates.save(row);
        }
        return new MessageResponse(p.bookings() == 0 ? "Rate saved."
                : "Rate saved. " + p.bookings() + " booking(s) in " + String.join(", ", p.months()) + " were recalculated.");
    }

    /** Remove any change except the starting row "2000-01", which can only be edited. */
    @Transactional
    public MessageResponse deleteRateChange(String effectiveFrom) {
        if (!rates.existsById(effectiveFrom)) throw ApiException.notFound("Rate not found.");
        if (BaseRateChange.BASE_FROM.equals(effectiveFrom))
            throw ApiException.bad("The base rate cannot be removed. Edit it instead.");
        String from = checkedFrom(effectiveFrom);
        List<RateLine> before = rateLines();
        RatePreview p = reprice(before, modified(before, from, null), true);
        rates.deleteById(effectiveFrom);
        return new MessageResponse(p.bookings() == 0 ? "Rate removed."
                : "Rate removed. " + p.bookings() + " booking(s) in " + String.join(", ", p.months()) + " were recalculated.");
    }

    private AppUser staffUser(String memberId) {
        return users.findById(memberId).filter(u -> u.getRole() == Role.STAFF)
                .orElseThrow(() -> ApiException.notFound("Staff member not found."));
    }
}
