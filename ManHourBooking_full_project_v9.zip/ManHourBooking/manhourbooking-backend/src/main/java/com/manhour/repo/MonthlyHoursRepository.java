package com.manhour.repo;

import com.manhour.model.MonthlyHours;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MonthlyHoursRepository extends JpaRepository<MonthlyHours, Long> {
    List<MonthlyHours> findByMemberId(String memberId);
    List<MonthlyHours> findByMonthAndYear(int month, int year);
    Optional<MonthlyHours> findByMemberIdAndMonthAndYear(String memberId, int month, int year);
    boolean existsByMemberIdAndMonthAndYear(String memberId, int month, int year);
}
