# ManHourBooking backend (Spring Boot 3 + MySQL)

Implements every endpoint in the frontend's `API_CONTRACT.md` (latest version: ONE base rate with dated changes).

## Run
1. Install JDK 17+, Maven, MySQL.
2. `export DB_USER=root DB_PASSWORD=yourpass JWT_SECRET=<32+ random chars>` (defaults exist for local dev only).
3. `mvn spring-boot:run`  (creates the `manhourbooking` database and tables automatically)
4. Frontend: in `.env` set `VITE_USE_MOCK=false` and `VITE_API_URL=http://localhost:8080`, then `npm run dev`.

First start seeds: base rate 500/h (from 2000-01) and admin `ADMIN01 / admin123`, clue answer `greenfield`. Change these.

## Forgot password (security question)
- `POST /api/auth/forgot/question {userId}` -> `{question}`
- `POST /api/auth/forgot/reset {userId, answer, newPassword}`
- Answer is stored as BCrypt of trim+lowercase. 5 wrong answers lock the account until an admin calls
  `PUT /api/admin/staff/{memberId}/password`, which also clears the lock.

## Base rate (admin)
- `GET /api/admin/base-rate`, `POST /api/admin/base-rate/changes {effectiveFrom:"YYYY-MM", rate}`,
  `DELETE /api/admin/base-rate/changes/{effectiveFrom}`
- A booking for month M uses the latest change with effectiveFrom <= M and saves it as `rate_applied`,
  so changing the rate never rewrites past bookings.

## Notes
- Money is BigDecimal (scale 2). Budget rows are locked (`PESSIMISTIC_WRITE`) while booking.
- Staff responses never contain rates, costs or budgets; staff can only read/edit their own data.

## Allocation, hours, rates and the monthly close
- Allocation: an employee's typed hours are 100% for the month. `PUT /api/admin/allocations/{memberId}` splits them across
  projects; percentage and hours always agree (% = hours / typed x 100). Percentages are decimals (`DECIMAL(5,2)`).
- Total hours: the admin can add or edit an employee's total hours for a month (`PUT /api/admin/allocations/{memberId}/hours`);
  it is the same record the employee sees, and cost and project budgets are recalculated.
- Base rate: when a rate row is added, edited or removed, bookings in OPEN months it covers are repriced (preview first via
  `POST /api/admin/base-rate/preview`). Finalized months never change.
- Project expiry no longer blocks anything. The only lock is a **finalized month**: `POST /api/admin/periods/finalize` locks one
  month (`period_lock`). While locked, every write that would change it is rejected. An admin can **reopen** it
  (`/periods/reopen`); every finalize and reopen is kept in `period_event` (who, when, reason).
- Upgrading an existing database: on start-up `SchemaFixer` (1) converts `booking.allocation_percentage` and
  `project_member_mapping.allocation_percentage` from INT to DECIMAL(5,2), and (2) copies months finalized by an earlier version
  (`period_closure`) into `period_lock`. By hand: `ALTER TABLE booking MODIFY allocation_percentage DECIMAL(5,2) NOT NULL;`
  `ALTER TABLE project_member_mapping MODIFY allocation_percentage DECIMAL(5,2) NOT NULL;`
  The old tables `period_closure` and `period_closure_line` are no longer used; you may drop them.
- No change to `pom.xml`.
