# ManHourBooking frontend

React 19 + Vite + Tailwind 4 + react-router + axios. It talks to the Spring Boot backend only:
no demo data and no mock server. The only thing saved in the browser is the login token, in
sessionStorage: a refresh keeps you logged in, closing the tab logs you out.

## Run
1. Start MySQL and the Spring Boot backend (http://localhost:8080).
2. In this folder:

```bash
npm install
npm run dev
```

3. Open http://localhost:5173 and log in with the backend's seeded admin: `ADMIN01 / admin123`.

No `.env` file is needed. If the backend is on another address, create `.env` with
`VITE_API_URL=http://your-backend:8080` and restart `npm run dev`.

## Screens
- `/login`, `/signup`, `/forgot-password` (clue-question reset)
- `/staff`: book hours, assigned projects, history with edit
- `/admin`: Dashboard (read-only, search), Projects, Member mapping (month, total hours, View / Edit / Assign, Finalize / Reopen), Staff and rates (rate changes recalculate open months)

Endpoints are listed in `API_CONTRACT.md`.
