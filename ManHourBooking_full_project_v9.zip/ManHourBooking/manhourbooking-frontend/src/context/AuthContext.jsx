import { createContext, useContext, useState } from "react";
import { api, clearSession, getSession, setSession } from "../api";

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [auth, setAuth] = useState(getSession);

  const persist = (res) => {
    setSession(res); // saved in sessionStorage so a refresh keeps you logged in
    setAuth(res);
    return res.user;
  };

  const login = async (userId, password) => persist(await api.login({ userId, password }));
  const signup = async (form) => persist(await api.signup(form));
  const logout = () => {
    clearSession();
    setAuth(null);
  };

  return (
    <AuthContext.Provider value={{ user: auth?.user ?? null, login, signup, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
