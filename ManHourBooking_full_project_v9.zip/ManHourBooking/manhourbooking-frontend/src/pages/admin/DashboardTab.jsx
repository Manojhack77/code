import { useEffect, useMemo, useState } from "react";
import { api } from "../../api";
import { Alert, Badge, Card, EmptyRow, Td, Th, inputCls } from "../../components/ui";
import { MONTHS, errMsg, fmtMoney, monthName } from "../../utils";

const thisYear = new Date().getFullYear();
const YEARS = Array.from({ length: 6 }, (_, i) => thisYear + 1 - i);

// FR-2.1: read-only, month-wise view of all bookings with filters (no page reload) and a search box.
// Hours are changed on the Member mapping page; a finalized month can no longer change at all.
export default function DashboardTab({ filters, setFilters }) {
  const { month, year, wbs, search } = filters;
  const change = (key) => (e) => setFilters((f) => ({ ...f, [key]: e.target.value }));
  const [projects, setProjects] = useState([]);
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    let stale = false;
    setLoading(true);
    api
      .adminBookings({ month: month || undefined, year: year || undefined })
      .then((r) => !stale && (setRows(r), setError("")))
      .catch((e) => !stale && setError(errMsg(e)))
      .finally(() => !stale && setLoading(false));
    return () => {
      stale = true;
    };
  }, [month, year]);

  // The WBS dropdown lists every project, even ones with no bookings in the current month or year.
  useEffect(() => {
    api
      .adminProjects()
      .then((list) => {
        setProjects(list);
        // A project deleted while you were on another tab would leave a filter that matches nothing.
        setFilters((f) => (f.wbs && !list.some((p) => p.wbsCode === f.wbs) ? { ...f, wbs: "" } : f));
      })
      .catch((e) => setError(errMsg(e)));
  }, [setFilters]);

  const visible = useMemo(() => {
    const q = search.trim().toLowerCase();
    return rows.filter(
      (r) =>
        (!wbs || r.wbsCode === wbs) &&
        (!q ||
          r.memberId.toLowerCase().includes(q) ||
          r.staffName.toLowerCase().includes(q) ||
          r.wbsCode.toLowerCase().includes(q) ||
          r.projectName.toLowerCase().includes(q)),
    );
  }, [rows, wbs, search]);

  const totalHours = visible.reduce((s, r) => s + r.hoursBooked, 0);
  const totalCost = visible.reduce((s, r) => s + r.calculatedCost, 0);

  return (
    <div>
      <div className="mb-5">
        <h2 className="text-xl font-semibold text-slate-800">Bookings</h2>
        <p className="mt-1 text-sm text-slate-500">All staff bookings, split by project. This view is read-only.</p>
      </div>

      <div className="mb-4 flex flex-wrap items-end gap-3">
        <label className="block min-w-56 flex-1 text-sm font-medium text-slate-700">
          <span className="mb-1.5 block">Search</span>
          <input
            type="search"
            className={inputCls}
            placeholder="Employee ID, name, WBS or project"
            value={search}
            onChange={change("search")}
          />
        </label>
        <label className="block text-sm font-medium text-slate-700">
          <span className="mb-1.5 block">Select WBS</span>
          <select className={`${inputCls} w-48`} value={wbs} onChange={change("wbs")}>
            <option value="">All projects</option>
            {projects.map((p) => (
              <option key={p.wbsCode} value={p.wbsCode}>{p.wbsCode}</option>
            ))}
          </select>
        </label>
        <label className="block text-sm font-medium text-slate-700">
          <span className="mb-1.5 block">Select month</span>
          <select className={`${inputCls} w-40`} value={month} onChange={change("month")}>
            <option value="">All months</option>
            {MONTHS.map((m, i) => (
              <option key={m} value={i + 1}>{m}</option>
            ))}
          </select>
        </label>
        <label className="block text-sm font-medium text-slate-700">
          <span className="mb-1.5 block">Select year</span>
          <select className={`${inputCls} w-32`} value={year} onChange={change("year")}>
            <option value="">All years</option>
            {YEARS.map((y) => (
              <option key={y} value={y}>{y}</option>
            ))}
          </select>
        </label>
      </div>

      <div className="mb-4"><Alert>{error}</Alert></div>

      <Card className="overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="border-b border-slate-200 bg-slate-50">
              <tr>
                <Th>Employee ID</Th>
                <Th>Employee name</Th>
                <Th>WBS code</Th>
                <Th>Project name</Th>
                <Th right>Hours booked</Th>
                <Th right>Cost</Th>
                <Th>Month</Th>
                <Th>Year</Th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {loading ? (
                <EmptyRow cols={8}>Loading...</EmptyRow>
              ) : visible.length === 0 ? (
                <EmptyRow cols={8}>No bookings match. Try another search, month or year.</EmptyRow>
              ) : (
                visible.map((r) => (
                  <tr key={r.bookingId} className="hover:bg-slate-50">
                    <Td strong>{r.memberId}</Td>
                    <Td>{r.staffName}</Td>
                    <Td strong>{r.wbsCode}</Td>
                    <Td>
                      {r.projectName} {r.projectExpired && <Badge tone="red">Expired</Badge>}
                    </Td>
                    <Td right strong>{r.hoursBooked}</Td>
                    <Td right>{fmtMoney(r.calculatedCost)}</Td>
                    <Td>{monthName(r.month)}</Td>
                    <Td>{r.year}</Td>
                  </tr>
                ))
              )}
            </tbody>
            {!loading && visible.length > 0 && (
              <tfoot className="border-t border-slate-200 bg-slate-50 text-sm font-medium text-slate-800">
                <tr>
                  <td className="px-5 py-3" colSpan={4}>Total for this view</td>
                  <td className="px-5 py-3 text-right">{Number(totalHours.toFixed(2))}</td>
                  <td className="px-5 py-3 text-right">{fmtMoney(totalCost)}</td>
                  <td colSpan={2} />
                </tr>
              </tfoot>
            )}
          </table>
        </div>
      </Card>
    </div>
  );
}
