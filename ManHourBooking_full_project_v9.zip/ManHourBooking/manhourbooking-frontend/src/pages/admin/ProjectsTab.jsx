import { useCallback, useEffect, useMemo, useState } from "react";
import { api } from "../../api";
import { Alert, Badge, Button, Card, EmptyRow, Field, Modal, Td, Th, inputCls } from "../../components/ui";
import { errMsg, fmtMoney } from "../../utils";

const EMPTY = { wbsCode: "", projectName: "", expiryDate: "", amountAllotted: "" };

// FR-2.3: project CRUD. Booked/available are computed by the system, never typed in.
export default function ProjectsTab() {
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [editing, setEditing] = useState(null); // null | "new" | project
  const [deleting, setDeleting] = useState(null);
  const [managing, setManaging] = useState(null); // project whose members are being edited

  const load = useCallback(async () => {
    try {
      setProjects(await api.adminProjects());
    } catch (e) {
      setError(errMsg(e));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const remove = async () => {
    try {
      const res = await api.deleteProject(deleting.wbsCode);
      setNotice(res?.message || `${deleting.wbsCode} deleted.`);
      setError("");
      await load();
    } catch (e) {
      setError(errMsg(e));
      setNotice("");
    }
    setDeleting(null);
  };

  return (
    <div>
      <div className="mb-5 flex items-end justify-between gap-4">
        <div>
          <h2 className="text-xl font-semibold text-slate-800">Projects</h2>
          <p className="mt-1 text-sm text-slate-500">WBS codes, expiry dates, budgets and the staff who work on each project.</p>
        </div>
        <Button onClick={() => setEditing("new")}>Add project</Button>
      </div>

      <div className="mb-4 space-y-2">
        <Alert>{error}</Alert>
        <Alert type="success">{notice}</Alert>
      </div>

      <Card className="overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="border-b border-slate-200 bg-slate-50">
              <tr>
                <Th>WBS code</Th>
                <Th>Project name</Th>
                <Th>Members</Th>
                <Th>Expiry date</Th>
                <Th>Allotted</Th>
                <Th>Booked</Th>
                <Th>Available</Th>
                <Th>Status</Th>
                <Th right>Action</Th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {loading ? (
                <EmptyRow cols={9}>Loading...</EmptyRow>
              ) : projects.length === 0 ? (
                <EmptyRow cols={9}>No projects yet. Add one to start assigning staff.</EmptyRow>
              ) : (
                projects.map((p) => {
                  const used = p.amountAllotted ? Math.min(100, (p.amountBooked / p.amountAllotted) * 100) : 0;
                  return (
                    <tr key={p.wbsCode} className="hover:bg-slate-50">
                      <Td strong>{p.wbsCode}</Td>
                      <Td>{p.projectName}</Td>
                      <Td>
                        <div className="flex max-w-56 flex-wrap items-center gap-1">
                          {p.members.length === 0 && <span className="text-slate-400">None</span>}
                          {p.members.slice(0, 3).map((m) => (
                            <span key={m.memberId} title={m.memberId}>
                              <Badge>{m.name}</Badge>
                            </span>
                          ))}
                          {p.members.length > 3 && (
                            <span title={p.members.slice(3).map((m) => m.name).join(", ")}>
                              <Badge>+{p.members.length - 3}</Badge>
                            </span>
                          )}
                          <Button small variant="ghost" onClick={() => setManaging(p)}>Manage</Button>
                        </div>
                      </Td>
                      <Td>{p.expiryDate}</Td>
                      <Td>{fmtMoney(p.amountAllotted)}</Td>
                      <Td>
                        {fmtMoney(p.amountBooked)}
                        <div className="mt-1 h-1.5 w-24 overflow-hidden rounded-full bg-slate-100" aria-hidden="true">
                          <div className={`h-full ${used > 90 ? "bg-red-500" : "bg-blue-500"}`} style={{ width: `${used}%` }} />
                        </div>
                      </Td>
                      <Td strong>{fmtMoney(p.amountAvailable)}</Td>
                      <Td>{p.status === "Expired" ? <Badge tone="red">Expired</Badge> : <Badge tone="green">Active</Badge>}</Td>
                      <Td right>
                        <span className="inline-flex gap-1">
                          <Button small variant="ghost" onClick={() => setEditing(p)}>Edit</Button>
                          <Button small variant="ghost" className="!text-red-600 hover:!bg-red-50" onClick={() => setDeleting(p)}>Delete</Button>
                        </span>
                      </Td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </Card>

      {editing && (
        <ProjectForm
          project={editing === "new" ? null : editing}
          onClose={() => setEditing(null)}
          onSaved={async (msg) => {
            setEditing(null);
            setNotice(msg);
            setError("");
            await load();
          }}
        />
      )}

      {managing && (
        <MembersModal
          project={managing}
          onClose={() => setManaging(null)}
          onSaved={async (msg) => {
            setManaging(null);
            setNotice(msg);
            setError("");
            await load();
          }}
        />
      )}

      {deleting && (
        <Modal title="Delete project?" onClose={() => setDeleting(null)}>
          <p className="text-sm text-slate-600">
            {deleting.projectName} ({deleting.wbsCode}) will be deleted together with <b>all its bookings and all staff
            assignments</b>. The hours staff typed for each month are kept; the part that was on this project becomes
            unassigned.
          </p>
          <p className="mt-2 text-sm font-medium text-red-700">This cannot be undone.</p>
          <div className="mt-5 flex justify-end gap-3">
            <Button variant="secondary" onClick={() => setDeleting(null)}>Cancel</Button>
            <Button variant="danger" onClick={remove}>Delete project and its data</Button>
          </div>
        </Modal>
      )}
    </div>
  );
}

// Pick the staff (app users) who work on a project. Only these people can be assigned to it on Member mapping.
function MembersModal({ project, onClose, onSaved }) {
  const [staff, setStaff] = useState([]);
  const [selected, setSelected] = useState(() => new Set(project.members.map((m) => m.memberId)));
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    api
      .adminStaff()
      .then(setStaff)
      .catch((e) => setError(errMsg(e)))
      .finally(() => setLoading(false));
  }, []);

  const visible = useMemo(() => {
    const q = search.trim().toLowerCase();
    return q ? staff.filter((s) => s.memberId.toLowerCase().includes(q) || s.name.toLowerCase().includes(q)) : staff;
  }, [staff, search]);

  const toggle = (id) =>
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });

  const save = async () => {
    setBusy(true);
    setError("");
    try {
      await api.setProjectMembers(project.wbsCode, [...selected]);
      await onSaved(`Members of ${project.wbsCode} saved.`);
    } catch (e) {
      setError(errMsg(e));
      setBusy(false);
    }
  };

  return (
    <Modal title={`Members of ${project.wbsCode}`} onClose={onClose}>
      <div className="space-y-4">
        <p className="text-sm text-slate-600">
          {project.projectName}. Only the people ticked here can be assigned to this project on the Member mapping page.
        </p>
        <input
          type="search" className={inputCls} placeholder="Search by employee ID or name" aria-label="Search staff"
          value={search} onChange={(e) => setSearch(e.target.value)}
        />
        <div className="max-h-72 divide-y divide-slate-100 overflow-y-auto rounded-lg border border-slate-200">
          {loading ? (
            <p className="px-4 py-6 text-center text-sm text-slate-500">Loading...</p>
          ) : visible.length === 0 ? (
            <p className="px-4 py-6 text-center text-sm text-slate-500">
              {staff.length === 0 ? "No staff have signed up yet." : "No employee matches your search."}
            </p>
          ) : (
            visible.map((s) => (
              <label key={s.memberId} className="flex cursor-pointer items-center gap-3 px-4 py-2.5 text-sm hover:bg-slate-50">
                <input type="checkbox" checked={selected.has(s.memberId)} onChange={() => toggle(s.memberId)} />
                <span className="font-medium text-slate-800">{s.name}</span>
                <span className="text-slate-500">{s.memberId}</span>
              </label>
            ))
          )}
        </div>
        <p className="text-xs text-slate-500">{selected.size} selected</p>
        <Alert>{error}</Alert>
        <div className="flex justify-end gap-3">
          <Button variant="secondary" onClick={onClose}>Cancel</Button>
          <Button onClick={save} disabled={busy || loading}>{busy ? "Saving..." : "Save members"}</Button>
        </div>
      </div>
    </Modal>
  );
}

function ProjectForm({ project, onClose, onSaved }) {
  const isNew = !project;
  const [form, setForm] = useState(
    isNew ? EMPTY : { ...project, amountAllotted: String(project.amountAllotted) },
  );
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

  const submit = async (e) => {
    e.preventDefault();
    if (!form.wbsCode.trim() || !form.projectName.trim() || !form.expiryDate)
      return setError("WBS code, project name and expiry date are required.");
    if (!(Number(form.amountAllotted) > 0)) return setError("Amount allotted must be greater than zero.");
    setBusy(true);
    setError("");
    const body = {
      wbsCode: form.wbsCode.trim(),
      projectName: form.projectName.trim(),
      expiryDate: form.expiryDate,
      amountAllotted: Number(form.amountAllotted),
    };
    try {
      if (isNew) await api.createProject(body);
      else await api.updateProject(project.wbsCode, body);
      await onSaved(isNew ? `${body.wbsCode.toUpperCase()} created.` : `${project.wbsCode} updated.`);
    } catch (err) {
      setError(errMsg(err));
      setBusy(false);
    }
  };

  return (
    <Modal title={isNew ? "Add project" : `Edit ${project.wbsCode}`} onClose={onClose}>
      <form onSubmit={submit} noValidate className="space-y-4">
        <Field label="WBS code">
          <input className={inputCls} value={form.wbsCode} onChange={set("wbsCode")} disabled={!isNew} autoFocus={isNew} />
        </Field>
        <Field label="Project name">
          <input className={inputCls} value={form.projectName} onChange={set("projectName")} autoFocus={!isNew} />
        </Field>
        <div className="grid grid-cols-2 gap-4">
          <Field label="Expiry date">
            <input type="date" className={inputCls} value={form.expiryDate} onChange={set("expiryDate")} />
          </Field>
          <Field label="Amount allotted (₹)">
            <input type="number" min="0" step="0.01" className={inputCls} value={form.amountAllotted} onChange={set("amountAllotted")} />
          </Field>
        </div>
        {!isNew && (
          <p className="text-xs text-slate-500">
            Available budget is recalculated as allotted minus booked ({fmtMoney(project.amountBooked)} booked).
          </p>
        )}
        <Alert>{error}</Alert>
        <div className="flex justify-end gap-3">
          <Button type="button" variant="secondary" onClick={onClose}>Cancel</Button>
          <Button type="submit" disabled={busy}>{busy ? "Saving..." : isNew ? "Create project" : "Save changes"}</Button>
        </div>
      </form>
    </Modal>
  );
}
