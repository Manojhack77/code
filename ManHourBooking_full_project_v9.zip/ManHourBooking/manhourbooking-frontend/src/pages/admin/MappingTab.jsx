import { useCallback, useEffect, useMemo, useState } from "react";
import { api } from "../../api";
import { Alert, Badge, Button, Card, EmptyRow, Modal, Td, Th, inputCls } from "../../components/ui";
import { MONTHS, errMsg, fmtDateTime, fmtNum, monthName } from "../../utils";
import AllocationModal from "./AllocationModal";
import FinalizeModal from "./FinalizeModal";

const now = new Date();
const YEARS = Array.from({ length: 6 }, (_, i) => now.getFullYear() + 1 - i);

// Member mapping for one month: total hours (add / edit in the table), allocation, and the month-end close.
export default function MappingTab() {
  const [month, setMonth] = useState(now.getMonth() + 1);
  const [year, setYear] = useState(now.getFullYear());
  const [staff, setStaff] = useState([]);
  const [projects, setProjects] = useState([]);
  const [status, setStatus] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [search, setSearch] = useState("");
  const [open, setOpen] = useState(null); // { mode, staff }
  const [hoursEdit, setHoursEdit] = useState(null); // { memberId, value }
  const [savingHours, setSavingHours] = useState(false);
  const [finalizing, setFinalizing] = useState(false);
  const [reopening, setReopening] = useState(false);
  const [reason, setReason] = useState("");
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    try {
      const [s, p, st] = await Promise.all([
        api.adminAllocations({ month, year }),
        api.adminProjects(),
        api.periodStatus({ month, year }),
      ]);
      setStaff(s);
      setProjects(p);
      setStatus(st);
      setError("");
    } catch (e) {
      setError(errMsg(e));
    } finally {
      setLoading(false);
    }
  }, [month, year]);

  useEffect(() => {
    setLoading(true);
    setHoursEdit(null);
    load();
  }, [load]);

  const visible = useMemo(() => {
    const q = search.trim().toLowerCase();
    return q ? staff.filter((s) => s.memberId.toLowerCase().includes(q) || s.name.toLowerCase().includes(q)) : staff;
  }, [staff, search]);

  const finalized = !!status?.finalized;
  const tone = (s) => (s.status === "Fully allocated" ? "green" : s.status === "Partly allocated" ? "amber" : "slate");

  const saveHours = async () => {
    const n = Number(hoursEdit.value);
    if (hoursEdit.value === "" || !(n >= 0)) return setError("Enter a valid number of hours.");
    setSavingHours(true);
    setError("");
    setNotice("");
    try {
      const res = await api.setMonthHours(hoursEdit.memberId, { month, year, hours: n });
      setNotice(res.message);
      setHoursEdit(null);
      await load();
    } catch (e) {
      setError(errMsg(e));
    } finally {
      setSavingHours(false);
    }
  };

  const reopen = async () => {
    setBusy(true);
    setError("");
    try {
      const res = await api.reopenPeriod({ month, year, reason });
      setNotice(res.message);
      setReopening(false);
      setReason("");
      await load();
    } catch (e) {
      setError(errMsg(e));
      setReopening(false);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="space-y-5">
      <div>
        <h2 className="text-xl font-semibold text-slate-800">Member mapping</h2>
        <p className="mt-1 text-sm text-slate-500">
          Each employee's hours for the month are 100%. Add or edit their total hours here, split them across projects, then finalize the month.
        </p>
      </div>

      <div className="flex flex-wrap items-end justify-between gap-4">
        <div className="flex flex-wrap items-end gap-3">
          <label className="block text-sm font-medium text-slate-700">
            <span className="mb-1.5 block">Month</span>
            <select className={`${inputCls} w-40`} value={month} onChange={(e) => setMonth(Number(e.target.value))}>
              {MONTHS.map((m, i) => <option key={m} value={i + 1}>{m}</option>)}
            </select>
          </label>
          <label className="block text-sm font-medium text-slate-700">
            <span className="mb-1.5 block">Year</span>
            <select className={`${inputCls} w-28`} value={year} onChange={(e) => setYear(Number(e.target.value))}>
              {YEARS.map((y) => <option key={y} value={y}>{y}</option>)}
            </select>
          </label>
          <div className="pb-2 text-sm">
            {finalized ? <Badge tone="green">Finalized</Badge> : <Badge tone="amber">Open</Badge>}
            {status?.doneBy && (finalized || status.lastAction === "REOPENED") && (
              <span className="ml-2 text-slate-500">
                {finalized ? "by" : "Reopened by"} {status.doneBy}, {fmtDateTime(status.doneAt)}
                {status.reason ? ` (${status.reason})` : ""}
              </span>
            )}
          </div>
          {finalized ? (
            <Button variant="secondary" onClick={() => setReopening(true)}>Reopen...</Button>
          ) : (
            <Button onClick={() => setFinalizing(true)} disabled={loading}>Finalize {monthName(month)}...</Button>
          )}
        </div>
        <label className="block min-w-64 text-sm font-medium text-slate-700">
          <span className="mb-1.5 block">Search</span>
          <input type="search" className={inputCls} placeholder="Employee ID or name" value={search} onChange={(e) => setSearch(e.target.value)} />
        </label>
      </div>

      <div className="space-y-2">
        <Alert>{error}</Alert>
        <Alert type="success">{notice}</Alert>
        {finalized && (
          <p className="rounded-lg border border-amber-200 bg-amber-50 px-4 py-2.5 text-sm text-amber-900">
            This month is finalized, so hours and allocations are read-only. Use Reopen to correct something.
          </p>
        )}
      </div>

      <Card className="overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="border-b border-slate-200 bg-slate-50">
              <tr>
                <Th>Employee ID</Th>
                <Th>Employee name</Th>
                <Th>Total hours</Th>
                <Th>Allocation</Th>
                <Th right>Action</Th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {loading ? (
                <EmptyRow cols={5}>Loading...</EmptyRow>
              ) : visible.length === 0 ? (
                <EmptyRow cols={5}>{staff.length === 0 ? "No staff have signed up yet." : "No employee matches your search."}</EmptyRow>
              ) : (
                visible.map((s) => {
                  const editing = hoursEdit?.memberId === s.memberId;
                  return (
                    <tr key={s.memberId} className="hover:bg-slate-50">
                      <Td strong>{s.memberId}</Td>
                      <Td>{s.name}</Td>
                      <Td>
                        {editing ? (
                          <span className="inline-flex items-center gap-2">
                            <input
                              type="number" min="0" max="744" step="0.01" autoFocus aria-label={`Total hours for ${s.name}`}
                              className={`${inputCls} w-28 py-1.5`} value={hoursEdit.value}
                              onChange={(e) => setHoursEdit({ memberId: s.memberId, value: e.target.value })}
                              onKeyDown={(e) => {
                                if (e.key === "Enter") saveHours();
                                if (e.key === "Escape") setHoursEdit(null);
                              }}
                            />
                            <Button small onClick={saveHours} disabled={savingHours}>Save</Button>
                            <Button small variant="secondary" onClick={() => setHoursEdit(null)}>Cancel</Button>
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-2">
                            <span className={s.typedHours == null ? "text-slate-400" : "font-medium text-slate-800"}>
                              {s.typedHours == null ? "none" : fmtNum(s.typedHours)}
                            </span>
                            <Button
                              small
                              variant="ghost"
                              disabled={finalized}
                              title={finalized ? "This month is finalized. Reopen it to change hours." : undefined}
                              onClick={() => { setHoursEdit({ memberId: s.memberId, value: s.typedHours == null ? "" : String(s.typedHours) }); setError(""); setNotice(""); }}
                            >
                              {s.typedHours == null ? "Add hours" : "Edit hours"}
                            </Button>
                          </span>
                        )}
                      </Td>
                      <Td>
                        <div className="flex flex-wrap items-center gap-3">
                          <div className="h-2 w-24 overflow-hidden rounded-full bg-slate-100" aria-hidden="true">
                            <div className={`h-full ${s.fromDefault ? "bg-slate-300" : "bg-blue-500"}`} style={{ width: `${Math.min(100, Number(s.totalPercent))}%` }} />
                          </div>
                          <span className={s.fromDefault ? "text-slate-500" : "text-slate-800"}>
                            {s.fromDefault ? "Default " : ""}{fmtNum(s.totalPercent)}% allocated
                          </span>
                          <span className="text-slate-500">{fmtNum(s.remainingPercent)}% remaining</span>
                          <Badge tone={tone(s)}>{s.status}</Badge>
                        </div>
                      </Td>
                      <Td right>
                        <span className="inline-flex gap-1">
                          <Button small variant="ghost" onClick={() => setOpen({ mode: "view", staff: s })}>View</Button>
                          <Button small variant="ghost" onClick={() => setOpen({ mode: "edit", staff: s })}>Edit</Button>
                          <Button small variant="ghost" disabled={Number(s.defaultRemainingPercent) <= 0} onClick={() => setOpen({ mode: "assign", staff: { ...s, totalPercent: 100 - Number(s.defaultRemainingPercent), remainingPercent: s.defaultRemainingPercent } })}>Assign</Button>
                        </span>
                      </Td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </Card>

      {open && (
        <AllocationModal
          mode={open.mode}
          staff={open.staff}
          projects={projects}
          period={{ month, year }}
          onClose={() => setOpen(null)}
          onDone={async (message) => {
            setOpen(null);
            setNotice(message);
            setError("");
            await load();
          }}
        />
      )}

      {finalizing && (
        <FinalizeModal
          month={month}
          year={year}
          projects={projects}
          onClose={() => setFinalizing(false)}
          onChanged={load}
          onDone={async (message) => {
            setFinalizing(false);
            setNotice(message);
            await load();
          }}
        />
      )}

      {reopening && (
        <Modal title={`Reopen ${monthName(month)} ${year}?`} onClose={() => setReopening(false)}>
          <p className="text-sm text-slate-700">
            Staff will be able to submit and edit hours for this month again, and you can change allocations and rates that cover it.
            Finalize it again when you are done. The reopen is recorded with your name.
          </p>
          <label className="mt-4 block text-sm font-medium text-slate-700">
            <span className="mb-1.5 block">Reason (optional)</span>
            <input className={inputCls} value={reason} maxLength={300} onChange={(e) => setReason(e.target.value)} placeholder="e.g. wrong hours for one employee" />
          </label>
          <div className="mt-5 flex justify-end gap-3">
            <Button variant="secondary" onClick={() => setReopening(false)}>Cancel</Button>
            <Button onClick={reopen} disabled={busy}>{busy ? "Reopening..." : "Reopen month"}</Button>
          </div>
        </Modal>
      )}
    </div>
  );
}
