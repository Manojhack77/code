import { useEffect, useState } from "react";
import { api } from "../../api";
import { Alert, Badge, Button, Field, Modal, Td, Th, inputCls } from "../../components/ui";
import { errMsg, fmtMoney, fmtNum, monthName, r2 } from "../../utils";

const periodKey = (m, y) => `${y}-${String(m).padStart(2, "0")}`;
// Projects this employee has been added to (Projects tab > Members). Nothing else can be assigned.
const projectsOf = (projects, memberId) => projects.filter((p) => p.members?.some((m) => m.memberId === memberId));
const num = (v) => (v === "" || v === null || v === undefined ? 0 : Number(v));

/** Assign / View / Edit for one employee. */
export default function AllocationModal({ mode, staff, projects, period: initialPeriod = null, onClose, onDone }) {
  const mine = projectsOf(projects, staff.memberId);
  if (mode === "assign") return <AssignForm staff={staff} projects={mine} onClose={onClose} onDone={onDone} />;
  return <Allocation mode={mode} staff={staff} projects={mine} initialPeriod={initialPeriod} onClose={onClose} onDone={onDone} />;
}

// ---------------------------------------------------------------- assign
function AssignForm({ staff, projects, onClose, onDone }) {
  const [wbs, setWbs] = useState("");
  const [pct, setPct] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const remaining = Number(staff.remainingPercent);

  const submit = async (e) => {
    e.preventDefault();
    if (!wbs) return setError("Choose a project.");
    if (!(num(pct) > 0)) return setError("Enter the allocation percentage.");
    if (num(pct) > remaining) return setError(`Only ${fmtNum(remaining)}% is left for ${staff.name}.`);
    setBusy(true);
    setError("");
    try {
      const res = await api.assignProject(staff.memberId, { wbsCode: wbs, percentage: num(pct) });
      onDone(res.message);
    } catch (err) {
      setError(errMsg(err));
      setBusy(false);
    }
  };

  return (
    <Modal title={`Assign a project to ${staff.name}`} onClose={onClose}>
      <form onSubmit={submit} noValidate className="space-y-4">
        <p className="text-sm text-slate-600">
          {staff.memberId}. Allocated {fmtNum(staff.totalPercent)}%, <strong>{fmtNum(remaining)}% remaining</strong>.
        </p>
        {projects.length === 0 && (
          <Alert>{staff.name} is not a member of any project yet. Add them to a project in the Projects tab first.</Alert>
        )}
        <Field label="Project (WBS)">
          <select className={inputCls} value={wbs} onChange={(e) => setWbs(e.target.value)} autoFocus disabled={projects.length === 0}>
            <option value="">Select project</option>
            {projects.map((p) => (
              <option key={p.wbsCode} value={p.wbsCode}>
                {p.wbsCode} - {p.projectName}{p.status === "Expired" ? " (expired)" : ""}
              </option>
            ))}
          </select>
        </Field>
        <Field label="Allocation %" hint="Hours already submitted in open months are split with this percentage too.">
          <input type="number" min="0" max="100" step="0.01" className={inputCls} value={pct} onChange={(e) => setPct(e.target.value)} />
        </Field>
        <Alert>{error}</Alert>
        <div className="flex justify-end gap-3">
          <Button type="button" variant="secondary" onClick={onClose}>Cancel</Button>
          <Button type="submit" disabled={busy || remaining <= 0 || projects.length === 0}>{busy ? "Assigning..." : "Assign"}</Button>
        </div>
      </form>
    </Modal>
  );
}

// ---------------------------------------------------------------- view / edit
function Allocation({ mode, staff, projects, initialPeriod, onClose, onDone }) {
  const [period, setPeriod] = useState(initialPeriod); // { month, year } or null = latest month with hours
  const [detail, setDetail] = useState(null);
  const [rows, setRows] = useState([]);
  const [applyDefault, setApplyDefault] = useState(false);
  const [addWbs, setAddWbs] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    let stale = false;
    setLoading(true);
    api
      .adminAllocation(staff.memberId, period ? { month: period.month, year: period.year } : {})
      .then((d) => {
        if (stale) return;
        setDetail(d);
        setRows(d.rows.map((r) => ({ wbsCode: r.wbsCode, projectName: r.projectName, expired: r.expired, hours: String(r.hours), pct: String(r.percentage) })));
        const latest = d.months[0];
        setApplyDefault(!!latest && latest.month === d.month && latest.year === d.year); // default: only for the latest month
        setError("");
      })
      .catch((e) => !stale && setError(errMsg(e)))
      .finally(() => !stale && setLoading(false));
    return () => {
      stale = true;
    };
  }, [staff.memberId, period]);

  const typed = detail?.typedHours == null ? 0 : Number(detail.typedHours);
  const editable = mode === "edit" && detail && detail.typedHours != null && !detail.finalized;

  // % and hours move together: typing one recalculates the other.
  const setPct = (i, v) =>
    setRows((rs) => rs.map((r, k) => (k === i ? { ...r, pct: v, hours: v === "" ? "" : String(r2((typed * num(v)) / 100)) } : r)));
  const setHours = (i, v) =>
    setRows((rs) => rs.map((r, k) => (k === i ? { ...r, hours: v, pct: v === "" || typed === 0 ? "" : String(r2((num(v) / typed) * 100)) } : r)));
  const removeRow = (i) => setRows((rs) => rs.filter((_, k) => k !== i));
  const addRow = (wbsCode) => {
    const p = projects.find((x) => x.wbsCode === wbsCode);
    if (!p) return;
    setRows((rs) => [...rs, { wbsCode, projectName: p.projectName, expired: p.status === "Expired", hours: "0", pct: "0" }]);
    setAddWbs("");
  };

  const totalPct = r2(rows.reduce((s, r) => s + num(r.pct), 0));
  const totalHours = r2(rows.reduce((s, r) => s + num(r.hours), 0));
  const remPct = r2(100 - totalPct);
  const remHours = r2(typed - totalHours);
  const negative = rows.some((r) => num(r.pct) < 0 || num(r.hours) < 0);
  const over = totalPct > 100.0001 || totalHours > typed + 0.0001;
  const hasExpired = rows.some((r) => r.expired);

  const save = async () => {
    setBusy(true);
    setError("");
    try {
      const res = await api.saveAllocation(staff.memberId, {
        month: detail.month,
        year: detail.year,
        applyToDefault: applyDefault,
        rows: rows.map((r) => ({ wbsCode: r.wbsCode, hours: num(r.hours) })),
      });
      onDone(res.message);
    } catch (err) {
      setError(errMsg(err));
      setBusy(false);
    }
  };

  const unused = projects.filter((p) => !rows.some((r) => r.wbsCode === p.wbsCode));

  return (
    <Modal wide title={`${mode === "edit" ? "Edit" : "View"} allocation: ${staff.name} (${staff.memberId})`} onClose={onClose}>
      {loading && !detail ? (
        <p className="text-sm text-slate-500">Loading...</p>
      ) : (
        detail && (
          <div className="space-y-4">
            <div className="flex flex-wrap items-end justify-between gap-3">
              <div className="flex flex-wrap items-end gap-4">
                <label className="block text-sm font-medium text-slate-700">
                  <span className="mb-1.5 block">Month</span>
                  <select
                    className={`${inputCls} w-48 py-1.5`}
                    value={periodKey(detail.month, detail.year)}
                    onChange={(e) => {
                      const [y, m] = e.target.value.split("-");
                      setPeriod({ month: Number(m), year: Number(y) });
                    }}
                  >
                    {detail.months.length === 0 && <option value={periodKey(detail.month, detail.year)}>{monthName(detail.month)} {detail.year}</option>}
                    {detail.months.map((m) => (
                      <option key={periodKey(m.month, m.year)} value={periodKey(m.month, m.year)}>
                        {monthName(m.month)} {m.year}{m.finalized ? " (final)" : ""}
                      </option>
                    ))}
                  </select>
                </label>
                <p className="pb-1.5 text-sm text-slate-700">
                  Hours booked: <strong>{detail.typedHours == null ? "none" : fmtNum(detail.typedHours)}</strong>
                  {detail.rate != null && <span className="ml-3 text-slate-500">Rate {fmtMoney(detail.rate)} / h</span>}
                </p>
              </div>
              {detail.finalized && <Badge tone="amber">Finalized, read-only</Badge>}
            </div>

            {detail.typedHours == null && (
              <Alert>No hours were submitted for this month, so there is nothing to split yet.</Alert>
            )}
            {mode === "edit" && detail.finalized && (
              <Alert>This month was finalized by the manager. Hours and costs can no longer be changed.</Alert>
            )}
            {editable && hasExpired && (
              <p className="rounded-lg border border-amber-200 bg-amber-50 px-4 py-2.5 text-sm text-amber-900">
                Some projects have expired. Give their share to current projects, then set the expired ones to 0 or remove them.
              </p>
            )}

            <div className="overflow-x-auto rounded-lg border border-slate-200">
              <table className="w-full text-left text-sm">
                <thead className="border-b border-slate-200 bg-slate-50">
                  <tr>
                    <Th>WBS code</Th>
                    <Th>Project name</Th>
                    <Th right>Allocation %</Th>
                    <Th right>Hours split</Th>
                    {!editable && <Th right>Cost</Th>}
                    {editable && <Th right>{" "}</Th>}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {rows.length === 0 ? (
                    <tr><td colSpan={5} className="px-5 py-6 text-center text-slate-500">No project has a share of this month yet.</td></tr>
                  ) : (
                    rows.map((r, i) => {
                      const live = detail.rows.find((x) => x.wbsCode === r.wbsCode);
                      return (
                        <tr key={r.wbsCode}>
                          <Td strong>{r.wbsCode}</Td>
                          <Td>{r.projectName} {r.expired && <Badge tone="red">Expired</Badge>}</Td>
                          <Td right>
                            {editable ? (
                              <input type="number" min="0" max="100" step="0.01" aria-label={`Percentage for ${r.wbsCode}`} className={`${inputCls} ml-auto w-28 py-1.5 text-right`} value={r.pct} onChange={(e) => setPct(i, e.target.value)} />
                            ) : (
                              `${fmtNum(r.pct)}%`
                            )}
                          </Td>
                          <Td right>
                            {editable ? (
                              <input type="number" min="0" step="0.01" aria-label={`Hours for ${r.wbsCode}`} className={`${inputCls} ml-auto w-28 py-1.5 text-right`} value={r.hours} onChange={(e) => setHours(i, e.target.value)} />
                            ) : (
                              fmtNum(r.hours)
                            )}
                          </Td>
                          {!editable && <Td right>{live ? fmtMoney(live.cost) : ""}</Td>}
                          {editable && (
                            <Td right>
                              <Button small variant="ghost" className="!text-red-600 hover:!bg-red-50" onClick={() => removeRow(i)}>Remove</Button>
                            </Td>
                          )}
                        </tr>
                      );
                    })
                  )}
                </tbody>
                <tfoot className="border-t border-slate-200 bg-slate-50 text-sm">
                  <tr className="font-medium text-slate-800">
                    <td className="px-5 py-2.5" colSpan={2}>Total</td>
                    <td className="px-5 py-2.5 text-right">{fmtNum(totalPct)}%</td>
                    <td className="px-5 py-2.5 text-right">{fmtNum(totalHours)}</td>
                    <td className="px-5 py-2.5 text-right">{!editable && fmtMoney(detail.totalCost)}</td>
                  </tr>
                  <tr className={remPct < -0.0001 || remHours < -0.0001 ? "font-medium text-red-700" : "text-slate-600"}>
                    <td className="px-5 py-2.5" colSpan={2}>Remaining</td>
                    <td className="px-5 py-2.5 text-right">{fmtNum(remPct)}%</td>
                    <td className="px-5 py-2.5 text-right">{detail.typedHours == null ? "" : fmtNum(remHours)}</td>
                    <td />
                  </tr>
                </tfoot>
              </table>
            </div>

            {editable && (
              <>
                <div className="flex flex-wrap items-end gap-3">
                  <label className="block text-sm font-medium text-slate-700">
                    <span className="mb-1.5 block">Add a project to this month</span>
                    <select className={`${inputCls} w-72 py-1.5`} value={addWbs} onChange={(e) => addRow(e.target.value)}>
                      <option value="">Select project</option>
                      {unused.map((p) => (
                        <option key={p.wbsCode} value={p.wbsCode}>{p.wbsCode} - {p.projectName}{p.status === "Expired" ? " (expired)" : ""}</option>
                      ))}
                    </select>
                  </label>
                </div>
                <label className="flex items-start gap-2 text-sm text-slate-700">
                  <input type="checkbox" className="mt-1" checked={applyDefault} onChange={(e) => setApplyDefault(e.target.checked)} />
                  <span>Use this split for months {staff.name} submits from now on (updates the default allocation).</span>
                </label>
                {over && <Alert>The total cannot go above 100% ({fmtNum(typed)} hours). Reduce a row first.</Alert>}
                {negative && <Alert>Percentages and hours cannot be negative.</Alert>}
              </>
            )}

            <Alert>{error}</Alert>
            <div className="flex justify-end gap-3">
              <Button variant="secondary" onClick={onClose}>{editable ? "Cancel" : "Close"}</Button>
              {editable && (
                <Button onClick={save} disabled={busy || over || negative}>{busy ? "Saving..." : "Save allocation"}</Button>
              )}
            </div>
          </div>
        )
      )}
    </Modal>
  );
}
