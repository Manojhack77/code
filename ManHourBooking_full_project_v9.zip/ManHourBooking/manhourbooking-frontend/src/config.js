// Backend address. Defaults to the Spring Boot backend on this computer.
// Override with VITE_API_URL in a .env file only if the backend runs somewhere else.
export const API_URL = import.meta.env.VITE_API_URL || "http://localhost:8080";
