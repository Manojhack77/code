# API contract (for the Spring Boot backend)

The frontend calls these endpoints. JWT goes in `Authorization: Bearer <token>`.
Errors: HTTP 4xx with JSON `{ "message": "..." }` (the UI shows `message` as-is). 401 sends the user to /login.
Money uses BigDecimal; months are integers 1-12.

## Auth (public)
- POST /api/auth/login   `{ userId, password }` -> `{ token, user: { memberId, name, role } }`  (role: STAFF | ADMIN)
- POST /api/auth/signup  `{ memberId, name, password, securityQuestion, securityAnswer }` -> same shape. Always creates STAFF.
  Store the password with BCrypt and the clue answer hashed too (trim + lowercase before hashing).
- POST /api/auth/forgot/question `{ userId }` -> `{ question }` (404 if no such user). Offline system: no email.
- POST /api/auth/forgot/reset `{ userId, answer, newPassword }` -> `{ message }`.
  Wrong answer -> 400 "That answer does not match."; lock after 5 wrong answers -> 400 "Too many wrong answers. Ask your administrator to reset your password."

## Staff (role STAFF)
- GET   /api/staff/projects/{memberId} -> `[{ wbsCode, projectName, expiryDate, status, allocationPercentage }]` (no budget, cost or rate fields) (only mapped projects, FR-1.1)
- GET   /api/staff/history/{memberId}  -> `[{ id, month, year, hours }]` one row per month, newest first. `hours` is the TOTAL the staff member typed, including any part not mapped to a project yet
- POST  /api/staff/book `{ memberId, month, year, hours }`
  Booking is allowed even with no (or only partial) project mapping: the typed total is always saved and shown to the staff member. Only the mapped % is costed; the unmapped part is allocated when an admin maps it (POST /api/admin/mappings backfills every month already submitted, skipping a month that would pass 100%, and refuses the mapping if the budget is short).
  Creates one Booking row per mapped WBS: hours_wbs = hours x allocation%, calculated_cost = hours_wbs x the base rate in force for the booked month, and the rate is saved on the row as rate_applied.
  Staff-facing error messages must NOT include rates, costs or budget amounts (use e.g. "Your account is not ready for booking yet" and "Not enough budget left in WBS-1001. Ask your administrator.").
  Rejects: month already booked or FINALIZED, cost > amount_available. An expired project does NOT block a booking. Single @Transactional.
- PATCH /api/staff/update-hours/{id}?hours=  (STAFF only)
  `id` is the `id` from history (`<memberId>_<year>_<month>`); the new total is re-split across that month's WBS rows by each row's saved %,
  each row keeps its own rate_applied. Rejected when the month is FINALIZED. Administrators no longer edit hours here (use PUT /api/admin/allocations).

## Admin (role ADMIN)
- GET    /api/admin/bookings?month=&year=  -> `[{ bookingId, wbsCode, projectName, memberId, staffName, hoursBooked, calculatedCost, month, year, projectExpired }]`
- GET    /api/admin/projects -> `[{ wbsCode, projectName, expiryDate, amountAllotted, amountAvailable, amountBooked, status, members: [{ memberId, name }] }]` (status = Expired when expiryDate < today)
- POST   /api/admin/projects `{ wbsCode, projectName, expiryDate, amountAllotted }`
- PUT    /api/admin/projects/{wbsCode} `{ projectName, expiryDate, amountAllotted }`  (available = allotted - booked; reject allotted < booked)
- PUT    /api/admin/projects/{wbsCode}/members `{ memberIds: ["..."] }` -> project (replaces the member list; staff only; 400 if a removed member still has an allocation or hours in an open month on it)
- DELETE /api/admin/projects/{wbsCode}  (rejected when the project appears in a finalized period)
- GET    /api/admin/staff -> `[{ memberId, name, totalAllocation }]`
- PUT    /api/admin/staff/{memberId}/password `{ password }`  (admin resets a staff password when the clue is forgotten; also clears the lock)
- GET    /api/admin/base-rate -> `{ rate, rateHistory: [{ effectiveFrom, rate }] }` (rate = in force this month; history newest first; first row effectiveFrom "2000-01")
- POST   /api/admin/base-rate/changes `{ effectiveFrom: "YYYY-MM", rate }`  (rate from that month for ALL staff. A NEW change may not start before the current month (400). Posting an existing effectiveFrom edits it, allowed only for the rate in force or an upcoming one; replaced rates are locked)
- DELETE /api/admin/base-rate/changes/{effectiveFrom}  (any row except the base row "2000-01", which can only be edited; 400 otherwise)
- GET    /api/admin/allocations?month=&year= -> `[{ memberId, name, typedHours|null, totalPercent, remainingPercent, defaultRemainingPercent, status, fromDefault, finalized }]`
  One row per staff for that month (default: current). With no hours that month, `fromDefault` is true and the standing (default) allocation is shown; status = No hours | Not assigned | Partly allocated | Fully allocated.
- GET    /api/admin/allocations/{memberId}?month=&year= -> `{ memberId, name, month, year, typedHours, finalized, rate, rows:[{ wbsCode, projectName, expired, percentage, hours, rate, cost }], totalPercent, totalHours, totalCost, remainingPercent, remainingHours, months:[{ month, year, typedHours, finalized }] }`
  (no month/year = latest month with submitted hours; typedHours = null when nothing was submitted)
- PUT    /api/admin/allocations/{memberId} `{ month, year, applyToDefault, rows:[{ wbsCode, hours }] }`
  Edit one month's split. % = hours / typed hours x 100 (2 decimals), cost = hours x the row's rate_applied (new rows use that month's base rate).
  Rows with 0 hours or missing from the request are removed and their cost is returned to the project. Rejects: month FINALIZED, sum of hours > typed hours (100%), unknown project.
  applyToDefault=true also makes the split the staff member's default for months submitted later.
- PUT    /api/admin/allocations/{memberId}/hours `{ month, year, hours }`  (ADMIN adds or edits an employee's TOTAL hours for a month)
  Same record the employee sees. Each row becomes hours x its %, cost at the row's saved rate, budgets move by the difference. A month with no hours is created from the default allocation.
  Rejects: month FINALIZED, hours < 0 or > 744, a project budget that cannot cover the change.
- POST   /api/admin/allocations/{memberId}/assign `{ wbsCode, percentage }`  (standing allocation; reject if the staff total would exceed 100 or the pair already exists; open months that fit are back-filled)

## One-month close (role ADMIN)
- GET    /api/admin/periods/status?month=&year= -> `{ period, finalized, lastAction:"FINALIZED"|"REOPENED"|null, doneBy, doneAt, reason }`
- GET    /api/admin/periods/check?month=&year= -> `{ month, year, finalized, staffTotal, staffWithHours, fullyAllocated, unassignedHours, issues:[{ memberId, name, type:"UNASSIGNED"|"EXPIRED"|"NO_HOURS", message }] }` (warnings only)
- POST   /api/admin/periods/finalize `{ month, year, reason? }`  locks that one month (period_lock) and writes period_event
- POST   /api/admin/periods/reopen   `{ month, year, reason? }`  removes the lock and writes period_event (audit trail: who, when, why)
While a month is finalized every write that changes its hours, % or cost is rejected (staff book/edit, admin hours/allocation/assign back-fill, rate recalculation, deleting a project that has bookings in it).

## Base rate (role ADMIN)
- POST   /api/admin/base-rate/preview `{ effectiveFrom, rate|null }` -> `{ bookings, months, lockedUnchanged, costDifference, budgetProblems }` (rate null = preview removing that row)
- POST   /api/admin/base-rate/changes `{ effectiveFrom, rate }` and DELETE /api/admin/base-rate/changes/{effectiveFrom}
  Bookings in OPEN months whose rate changes are repriced (hours x new rate, rate_applied updated, budgets adjusted) in one transaction; if a budget cannot cover it, nothing is saved.
  Finalized months never change. A row can be added/edited/removed only when its start month is open ("2000-01" can always be edited). Past months are allowed.

## Rules the backend must enforce (spec FR-3.x, section 5)
Amount Booked += cost; Amount Available -= cost; Available = Allotted - Booked always; project expiry is information only (no lock): the only lock is a FINALIZED month, after which hours, % and cost of that month never change; RBAC on every route.
Rate: ONE base hourly rate for all staff with dated changes (history). A booking for month M uses the latest change whose effectiveFrom <= M and stores it as rate_applied. Edits of an existing booking use that row's rate_applied, so changing the rate never rewrites history.
Rates, costs and budgets are admin-only: no STAFF endpoint may return them.
